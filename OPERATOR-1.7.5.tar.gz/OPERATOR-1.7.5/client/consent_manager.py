#!/usr/bin/env python3
"""
OPERATOR Consent Manager — Explicit consent for irreversible actions.

Before any agent does something that can't be undone, it must pause
and request confirmation from the user.
"""

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Literal

# Paths
OPERATOR_DIR = Path.home() / ".operator"
CONFIG_FILE = OPERATOR_DIR / "config.json"
AUDIT_LOG = OPERATOR_DIR / "audit.log"
CONSENT_PENDING = OPERATOR_DIR / "consent_pending.json"

# Irreversible actions that require consent
IRREVERSIBLE_ACTIONS = [
    "FILE_DELETE",
    "PR_SUBMIT",
    "EMAIL_SEND",
    "PUBLIC_POST",
    "CRON_DELETE",
    "STRIPE_CHARGE",
    "DATABASE_DROP",
    "DEPLOY_PRODUCTION",
]

# Default consent timeout (5 minutes)
CONSENT_TIMEOUT_SECONDS = 300


def load_config() -> dict:
    """Load OPERATOR config."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def save_config(config: dict) -> None:
    """Save OPERATOR config."""
    OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def get_capability_level() -> int:
    """Get current capability level (1=Safe, 2=Extended, 3=Full)."""
    config = load_config()
    return config.get("capability_level", 1)


def requires_consent(action: str) -> bool:
    """Check if an action requires explicit consent at current capability level.
    
    Args:
        action: Action type (e.g., "PR_SUBMIT", "FILE_DELETE")
        
    Returns:
        True if consent is required
    """
    if action not in IRREVERSIBLE_ACTIONS:
        return False
    
    level = get_capability_level()
    
    if level == 1:  # Safe Mode: ALL irreversible actions require consent
        return True
    
    if level == 2:  # Extended Access: only external actions require consent
        external_actions = ["PR_SUBMIT", "EMAIL_SEND", "PUBLIC_POST", "STRIPE_CHARGE", "DEPLOY_PRODUCTION"]
        return action in external_actions
    
    # Level 3 (Full Power): consent optional but logged
    return False


def request_consent(
    agent: str,
    action: str,
    description: str,
    channel: Optional[str] = None,
) -> tuple[bool, str]:
    """Request consent for an irreversible action.
    
    This creates a consent request and waits for approval.
    In a full implementation, this would post to Discord and wait for a response.
    For now, it creates a pending consent file that can be approved via CLI.
    
    Args:
        agent: Agent requesting consent
        action: Action type
        description: Human-readable description of what will happen
        channel: Optional Discord channel to post to
        
    Returns:
        (approved: bool, message: str)
    """
    request_id = f"{agent}_{action}_{int(time.time())}"
    
    # Create pending consent request
    request = {
        "id": request_id,
        "agent": agent,
        "action": action,
        "description": description,
        "requested_at": datetime.now(timezone.utc).isoformat(),
        "expires_at": datetime.fromtimestamp(
            time.time() + CONSENT_TIMEOUT_SECONDS, tz=timezone.utc
        ).isoformat(),
        "status": "pending",
        "channel": channel,
    }
    
    # Save pending request
    _save_pending(request)
    
    # Log the consent request
    _log_audit(agent, "CONSENT_REQUEST", f"action={action} desc={description[:50]}")
    
    # In a full implementation, we'd post to Discord here and wait
    # For now, we'll check for approval via file-based mechanism
    
    # Poll for response (with timeout)
    start_time = time.time()
    while time.time() - start_time < CONSENT_TIMEOUT_SECONDS:
        pending = _load_pending(request_id)
        if not pending:
            # Request was processed
            return False, "Consent request was cancelled"
        
        if pending.get("status") == "approved":
            _log_audit(agent, "CONSENT_GRANTED", f"action={action}")
            _clear_pending(request_id)
            return True, "Consent granted"
        
        if pending.get("status") == "denied":
            _log_audit(agent, "CONSENT_DENIED", f"action={action}")
            _clear_pending(request_id)
            return False, "Consent denied"
        
        # Wait before checking again (in real impl, we'd use async/events)
        time.sleep(1)
    
    # Timeout
    _log_audit(agent, "CONSENT_TIMEOUT", f"action={action}")
    _clear_pending(request_id)
    return False, "Consent request timed out"


def approve_consent(request_id: str, approver: str = "user") -> bool:
    """Approve a pending consent request.
    
    Args:
        request_id: ID of the consent request
        approver: Who approved (for audit trail)
        
    Returns:
        True if approved successfully
    """
    pending = _load_pending(request_id)
    if not pending:
        return False
    
    pending["status"] = "approved"
    pending["approved_by"] = approver
    pending["approved_at"] = datetime.now(timezone.utc).isoformat()
    _save_pending(pending)
    return True


def deny_consent(request_id: str, reason: str = "user denied") -> bool:
    """Deny a pending consent request.
    
    Args:
        request_id: ID of the consent request
        reason: Reason for denial
        
    Returns:
        True if denied successfully
    """
    pending = _load_pending(request_id)
    if not pending:
        return False
    
    pending["status"] = "denied"
    pending["denied_reason"] = reason
    pending["denied_at"] = datetime.now(timezone.utc).isoformat()
    _save_pending(pending)
    return True


def list_pending() -> list[dict]:
    """List all pending consent requests."""
    if not CONSENT_PENDING.exists():
        return []
    
    try:
        with open(CONSENT_PENDING) as f:
            all_pending = json.load(f)
    except Exception:
        return []
    
    # Filter to only pending ones that haven't expired
    now = datetime.now(timezone.utc)
    result = []
    for req in all_pending.values():
        if req.get("status") != "pending":
            continue
        expires = datetime.fromisoformat(req["expires_at"].replace("Z", "+00:00"))
        if now < expires:
            result.append(req)
    
    return result


def get_consent_mode() -> str:
    """Get current consent mode based on capability level."""
    level = get_capability_level()
    if level == 1:
        return "strict"  # All irreversible actions require consent
    elif level == 2:
        return "external"  # Only external actions require consent
    else:
        return "optional"  # Consent is optional but logged


def set_consent_mode(mode: Literal["strict", "external", "optional"]) -> None:
    """Set consent mode directly in config."""
    config = load_config()
    config["consent_mode"] = mode
    save_config(config)


# ── Discord Integration ──────────────────────────────────────────────────────

def format_consent_message(agent: str, action: str, description: str) -> str:
    """Format a consent request message for Discord."""
    return f"""⚠️ **CONSENT REQUIRED**

**Agent:** {agent}
**Action:** {action}
**Description:** {description}

Reply **YES** to approve or **NO** to deny.
This request expires in 5 minutes."""


def post_consent_to_discord(
    agent: str,
    action: str,
    description: str,
    channel_id: str,
    bot_token: str,
) -> Optional[str]:
    """Post a consent request to Discord and return message ID.
    
    Returns message ID if successful, None otherwise.
    """
    import urllib.request
    import urllib.error
    
    message = format_consent_message(agent, action, description)
    
    url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
    data = json.dumps({"content": message}).encode("utf-8")
    
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bot {bot_token}",
        }
    )
    
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
            return result.get("id")
    except Exception:
        return None


# ── Internal helpers ─────────────────────────────────────────────────────────

def _load_pending(request_id: str) -> Optional[dict]:
    """Load a specific pending request."""
    if not CONSENT_PENDING.exists():
        return None
    
    try:
        with open(CONSENT_PENDING) as f:
            all_pending = json.load(f)
        return all_pending.get(request_id)
    except Exception:
        return None


def _save_pending(request: dict) -> None:
    """Save a pending request."""
    OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
    
    all_pending = {}
    if CONSENT_PENDING.exists():
        try:
            with open(CONSENT_PENDING) as f:
                all_pending = json.load(f)
        except Exception:
            pass
    
    all_pending[request["id"]] = request
    
    with open(CONSENT_PENDING, "w") as f:
        json.dump(all_pending, f, indent=2)


def _clear_pending(request_id: str) -> None:
    """Clear a pending request."""
    if not CONSENT_PENDING.exists():
        return
    
    try:
        with open(CONSENT_PENDING) as f:
            all_pending = json.load(f)
        
        if request_id in all_pending:
            del all_pending[request_id]
            
            with open(CONSENT_PENDING, "w") as f:
                json.dump(all_pending, f, indent=2)
    except Exception:
        pass


def _log_audit(agent: str, event: str, details: str) -> None:
    """Append to audit log."""
    OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).isoformat()
    entry = f"[{timestamp}] [{agent.upper()}] {event} {details}\n"
    with open(AUDIT_LOG, "a") as f:
        f.write(entry)


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="OPERATOR Consent Manager")
    sub = parser.add_subparsers(dest="cmd")
    
    # request (for testing)
    p_req = sub.add_parser("request", help="Request consent (test)")
    p_req.add_argument("--agent", required=True)
    p_req.add_argument("--action", required=True)
    p_req.add_argument("--description", required=True)
    
    # approve
    p_approve = sub.add_parser("approve", help="Approve a consent request")
    p_approve.add_argument("request_id")
    
    # deny
    p_deny = sub.add_parser("deny", help="Deny a consent request")
    p_deny.add_argument("request_id")
    p_deny.add_argument("--reason", default="user denied")
    
    # list
    sub.add_parser("list", help="List pending consent requests")
    
    # status
    sub.add_parser("status", help="Show current consent mode")
    
    args = parser.parse_args()
    
    if args.cmd == "request":
        print(f"Requesting consent for {args.action}...")
        approved, msg = request_consent(args.agent, args.action, args.description)
        print(f"Result: {'✅ Approved' if approved else '❌ Denied'} - {msg}")
    
    elif args.cmd == "approve":
        if approve_consent(args.request_id):
            print(f"✅ Approved: {args.request_id}")
        else:
            print(f"❌ Request not found: {args.request_id}")
    
    elif args.cmd == "deny":
        if deny_consent(args.request_id, args.reason):
            print(f"❌ Denied: {args.request_id}")
        else:
            print(f"Request not found: {args.request_id}")
    
    elif args.cmd == "list":
        pending = list_pending()
        if not pending:
            print("No pending consent requests")
        else:
            for req in pending:
                print(f"• {req['id']}")
                print(f"  Agent: {req['agent']}")
                print(f"  Action: {req['action']}")
                print(f"  Description: {req['description']}")
                print(f"  Expires: {req['expires_at']}")
                print()
    
    elif args.cmd == "status":
        mode = get_consent_mode()
        level = get_capability_level()
        print(f"Capability Level: {level}")
        print(f"Consent Mode: {mode}")
        print()
        print("Irreversible actions requiring consent:")
        for action in IRREVERSIBLE_ACTIONS:
            req = requires_consent(action)
            status = "⚠️ REQUIRES CONSENT" if req else "✓ no consent needed"
            print(f"  • {action}: {status}")
    
    else:
        parser.print_help()
