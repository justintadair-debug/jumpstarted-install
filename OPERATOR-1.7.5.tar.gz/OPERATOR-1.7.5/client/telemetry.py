#!/usr/bin/env python3
"""
JUMPSTARTED Anonymous Telemetry Module.

Collects anonymous crash reports and usage stats from opt-in users.
NEVER collects personal data, messages, or file contents.

All network calls silently fail - telemetry NEVER crashes the product.
"""

import json
import os
import platform
import sys
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Configuration
TELEMETRY_ENDPOINT = os.environ.get(
    "JUMPSTARTED_TELEMETRY_URL",
    "https://operator-license-server.fly.dev"  # Use existing Fly.io server
)
OPERATOR_DIR = Path.home() / ".operator"
CONFIG_FILE = OPERATOR_DIR / "config.json"
LOCAL_TELEMETRY_LOG = OPERATOR_DIR / "telemetry_local.jsonl"

# Timeout for telemetry requests (don't slow down the product)
REQUEST_TIMEOUT = 5


def is_telemetry_enabled() -> bool:
    """Check if telemetry is enabled in config.
    
    Returns False if:
    - Config doesn't exist
    - telemetry_enabled is not set
    - telemetry_enabled is explicitly False
    """
    try:
        if not CONFIG_FILE.exists():
            return False
        with open(CONFIG_FILE) as f:
            config = json.load(f)
        return config.get("telemetry_enabled", False) is True
    except Exception:
        return False


def set_telemetry_enabled(enabled: bool) -> None:
    """Set telemetry preference in config."""
    try:
        config = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE) as f:
                config = json.load(f)
        
        config["telemetry_enabled"] = enabled
        
        OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass  # Silent fail


def get_version() -> str:
    """Get OPERATOR version."""
    version_file = OPERATOR_DIR / "VERSION"
    try:
        if version_file.exists():
            return version_file.read_text().strip()
    except Exception:
        pass
    return "unknown"


def get_anonymous_context() -> dict:
    """Get anonymous system context (no personal info)."""
    return {
        "version": get_version(),
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "arch": platform.machine(),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def send_crash_report(
    error_type: str,
    step: str,
    error_message: Optional[str] = None,
) -> bool:
    """Send anonymous crash report.
    
    Args:
        error_type: Type of error (e.g., "ImportError", "ConnectionError")
        step: Which step failed (e.g., "discord_setup", "license_validation")
        error_message: Brief error message (sanitized, no paths or personal info)
        
    Returns:
        True if sent successfully, False otherwise
    """
    if not is_telemetry_enabled():
        return False
    
    payload = {
        "type": "crash",
        "error_type": error_type,
        "step": step,
        "error_message": _sanitize_message(error_message) if error_message else None,
        **get_anonymous_context(),
    }
    
    return _send_telemetry("/v1/telemetry/crash", payload)


def send_install_funnel(
    step_reached: str,
    completed: bool,
    duration_seconds: Optional[int] = None,
) -> bool:
    """Send anonymous install funnel data.
    
    Args:
        step_reached: Last step reached (e.g., "license", "discord", "complete")
        completed: Whether setup completed successfully
        duration_seconds: How long the install took
        
    Returns:
        True if sent successfully
    """
    if not is_telemetry_enabled():
        return False
    
    payload = {
        "type": "funnel",
        "step_reached": step_reached,
        "completed": completed,
        "duration_seconds": duration_seconds,
        **get_anonymous_context(),
    }
    
    return _send_telemetry("/v1/telemetry/funnel", payload)


def send_weekly_stats(
    agent_responses_count: int,
    capability_level: int,
    crons_count: int,
    tasks_completed: int = 0,
) -> bool:
    """Send anonymous weekly usage stats.
    
    Args:
        agent_responses_count: Number of agent responses this week
        capability_level: Current capability level (1-3)
        crons_count: Number of active crons
        tasks_completed: Number of tasks completed
        
    Returns:
        True if sent successfully
    """
    if not is_telemetry_enabled():
        return False
    
    payload = {
        "type": "weekly_stats",
        "agent_responses": agent_responses_count,
        "capability_level": capability_level,
        "crons_count": crons_count,
        "tasks_completed": tasks_completed,
        **get_anonymous_context(),
    }
    
    return _send_telemetry("/v1/telemetry/stats", payload)


def send_startup() -> bool:
    """Send anonymous startup event."""
    if not is_telemetry_enabled():
        return False
    
    payload = {
        "type": "startup",
        **get_anonymous_context(),
    }
    
    return _send_telemetry("/v1/telemetry/event", payload)


# ── Internal helpers ─────────────────────────────────────────────────────────

def _send_telemetry(endpoint: str, payload: dict) -> bool:
    """Send telemetry data to server.
    
    NEVER raises exceptions - all errors are silently ignored.
    Telemetry must NEVER crash the product.
    """
    try:
        url = f"{TELEMETRY_ENDPOINT}{endpoint}"
        data = json.dumps(payload).encode("utf-8")
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return resp.status == 200
    except Exception:
        # Log locally as fallback
        _log_locally(payload)
        return False


def _log_locally(payload: dict) -> None:
    """Log telemetry data locally as fallback."""
    try:
        OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOCAL_TELEMETRY_LOG, "a") as f:
            f.write(json.dumps(payload) + "\n")
    except Exception:
        pass  # Silent fail


def _sanitize_message(message: str) -> str:
    """Remove potential personal info from error messages."""
    if not message:
        return ""
    
    # Remove file paths
    import re
    message = re.sub(r'/Users/[^/\s]+', '/Users/***', message)
    message = re.sub(r'/home/[^/\s]+', '/home/***', message)
    message = re.sub(r'C:\\Users\\[^\\]+', 'C:\\Users\\***', message)
    
    # Remove potential tokens/keys (long alphanumeric strings)
    message = re.sub(r'[A-Za-z0-9_-]{40,}', '***TOKEN***', message)
    
    # Truncate
    return message[:200]


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="JUMPSTARTED Telemetry")
    sub = parser.add_subparsers(dest="cmd")
    
    # status
    sub.add_parser("status", help="Check telemetry status")
    
    # enable
    sub.add_parser("enable", help="Enable telemetry")
    
    # disable
    sub.add_parser("disable", help="Disable telemetry")
    
    # test
    sub.add_parser("test", help="Send test event")
    
    args = parser.parse_args()
    
    if args.cmd == "status":
        enabled = is_telemetry_enabled()
        print(f"Telemetry: {'✅ Enabled' if enabled else '❌ Disabled'}")
        print(f"Endpoint: {TELEMETRY_ENDPOINT}")
        print(f"Version: {get_version()}")
    
    elif args.cmd == "enable":
        set_telemetry_enabled(True)
        print("✅ Telemetry enabled")
    
    elif args.cmd == "disable":
        set_telemetry_enabled(False)
        print("❌ Telemetry disabled")
    
    elif args.cmd == "test":
        if not is_telemetry_enabled():
            print("Telemetry is disabled. Enable with: python telemetry.py enable")
        else:
            print("Sending test event...")
            if send_startup():
                print("✅ Test event sent successfully")
            else:
                print("⚠️ Failed to send (logged locally)")
    
    else:
        parser.print_help()
