#!/usr/bin/env python3
"""
OPERATOR Skill Verifier — SHA-256 digest verification for skill packs.

Prevents tampered or malicious skill files from running by verifying
file hashes against a known-good registry.
"""

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Paths
OPERATOR_DIR = Path.home() / ".operator"
SKILL_REGISTRY = OPERATOR_DIR / "skill_registry.json"
AUDIT_LOG = OPERATOR_DIR / "audit.log"


def calculate_hash(file_path: str | Path) -> str:
    """Calculate SHA-256 hash of a file.
    
    Args:
        file_path: Path to the file to hash
        
    Returns:
        SHA-256 hex digest string
    """
    sha256 = hashlib.sha256()
    path = Path(file_path)
    
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    
    return sha256.hexdigest()


def verify_skill(skill_path: str | Path, expected_hash: str) -> bool:
    """Verify a skill file matches its expected hash.
    
    Args:
        skill_path: Path to the skill file
        expected_hash: Expected SHA-256 hex digest
        
    Returns:
        True if hash matches, False otherwise
    """
    try:
        actual_hash = calculate_hash(skill_path)
        return actual_hash.lower() == expected_hash.lower()
    except Exception:
        return False


def verify_file_against_registry(file_path: str | Path, registry_path: str | Path) -> tuple[bool, str]:
    """Verify a file against a HASHES.txt registry.
    
    Args:
        file_path: Path to the file to verify
        registry_path: Path to HASHES.txt file
        
    Returns:
        (verified: bool, message: str)
    """
    file_path = Path(file_path)
    registry_path = Path(registry_path)
    
    if not registry_path.exists():
        return False, f"Registry file not found: {registry_path}"
    
    # Parse HASHES.txt format: "hash  filename"
    expected_hashes = {}
    with open(registry_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                hash_val, filename = parts
                expected_hashes[filename.strip()] = hash_val.strip()
    
    filename = file_path.name
    if filename not in expected_hashes:
        return False, f"File '{filename}' not found in registry"
    
    expected = expected_hashes[filename]
    actual = calculate_hash(file_path)
    
    if actual.lower() == expected.lower():
        return True, f"Verified: {filename}"
    else:
        return False, f"HASH MISMATCH: {filename} (expected {expected[:16]}..., got {actual[:16]}...)"


def register_skill(skill_name: str, file_path: str | Path) -> dict:
    """Register a skill with its hash in the local registry.
    
    Args:
        skill_name: Name of the skill
        file_path: Path to the skill file
        
    Returns:
        Registry entry dict
    """
    file_path = Path(file_path)
    file_hash = calculate_hash(file_path)
    
    # Load existing registry
    registry = _load_registry()
    
    # Create entry
    entry = {
        "name": skill_name,
        "file": str(file_path),
        "hash": file_hash,
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "verified": True,
    }
    
    registry[skill_name] = entry
    _save_registry(registry)
    
    # Log to audit
    _log_audit("SKILL_INSTALL", f"name={skill_name} hash={file_hash[:16]}... verified=true")
    
    return entry


def unregister_skill(skill_name: str) -> bool:
    """Remove a skill from the registry.
    
    Args:
        skill_name: Name of the skill to remove
        
    Returns:
        True if removed, False if not found
    """
    registry = _load_registry()
    
    if skill_name not in registry:
        return False
    
    del registry[skill_name]
    _save_registry(registry)
    
    _log_audit("SKILL_UNINSTALL", f"name={skill_name}")
    return True


def list_skills() -> list[dict]:
    """List all registered skills with hash and install date.
    
    Returns:
        List of skill entry dicts
    """
    registry = _load_registry()
    return list(registry.values())


def verify_all_skills() -> list[dict]:
    """Verify all registered skills still match their hashes.
    
    Returns:
        List of verification results
    """
    registry = _load_registry()
    results = []
    
    for name, entry in registry.items():
        file_path = Path(entry["file"])
        if not file_path.exists():
            results.append({
                "name": name,
                "status": "missing",
                "message": f"File not found: {file_path}"
            })
            continue
        
        current_hash = calculate_hash(file_path)
        if current_hash.lower() == entry["hash"].lower():
            results.append({
                "name": name,
                "status": "verified",
                "message": "Hash matches"
            })
        else:
            results.append({
                "name": name,
                "status": "tampered",
                "message": f"Hash mismatch! Expected {entry['hash'][:16]}..., got {current_hash[:16]}..."
            })
            _log_audit("SKILL_TAMPER_DETECTED", f"name={name} expected={entry['hash'][:16]} actual={current_hash[:16]}")
    
    return results


def verify_installer_files(installer_dir: str | Path) -> tuple[bool, list[str]]:
    """Verify all files in an installer package against HASHES.txt.
    
    Args:
        installer_dir: Path to the extracted installer directory
        
    Returns:
        (all_valid: bool, messages: list[str])
    """
    installer_dir = Path(installer_dir)
    hashes_file = installer_dir / "HASHES.txt"
    
    if not hashes_file.exists():
        return False, ["HASHES.txt not found in installer package"]
    
    # Parse HASHES.txt
    expected_hashes = {}
    with open(hashes_file) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                hash_val, filename = parts
                expected_hashes[filename.strip()] = hash_val.strip()
    
    messages = []
    all_valid = True
    
    for filename, expected_hash in expected_hashes.items():
        file_path = installer_dir / filename
        if not file_path.exists():
            messages.append(f"⚠️ Missing file: {filename}")
            all_valid = False
            continue
        
        actual_hash = calculate_hash(file_path)
        if actual_hash.lower() == expected_hash.lower():
            messages.append(f"✓ Verified: {filename}")
        else:
            messages.append(f"❌ TAMPERED: {filename}")
            all_valid = False
            _log_audit("INSTALLER_TAMPER_DETECTED", f"file={filename} expected={expected_hash[:16]} actual={actual_hash[:16]}")
    
    return all_valid, messages


# ── Internal helpers ─────────────────────────────────────────────────────────

def _load_registry() -> dict:
    """Load the skill registry from disk."""
    if not SKILL_REGISTRY.exists():
        return {}
    try:
        with open(SKILL_REGISTRY) as f:
            return json.load(f)
    except Exception:
        return {}


def _save_registry(registry: dict) -> None:
    """Save the skill registry to disk."""
    OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
    with open(SKILL_REGISTRY, "w") as f:
        json.dump(registry, f, indent=2)


def _log_audit(event: str, details: str) -> None:
    """Append to audit log."""
    OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).isoformat()
    entry = f"[{timestamp}] [VERIFIER] {event} {details}\n"
    with open(AUDIT_LOG, "a") as f:
        f.write(entry)


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="OPERATOR Skill Verifier")
    sub = parser.add_subparsers(dest="cmd")
    
    # hash
    p_hash = sub.add_parser("hash", help="Calculate SHA-256 hash of a file")
    p_hash.add_argument("file", help="File to hash")
    
    # verify
    p_verify = sub.add_parser("verify", help="Verify file against expected hash")
    p_verify.add_argument("file", help="File to verify")
    p_verify.add_argument("expected_hash", help="Expected SHA-256 hash")
    
    # register
    p_reg = sub.add_parser("register", help="Register a skill")
    p_reg.add_argument("name", help="Skill name")
    p_reg.add_argument("file", help="Skill file path")
    
    # list
    sub.add_parser("list", help="List registered skills")
    
    # check
    sub.add_parser("check", help="Verify all registered skills")
    
    # verify-installer
    p_inst = sub.add_parser("verify-installer", help="Verify installer package")
    p_inst.add_argument("dir", help="Installer directory")
    
    args = parser.parse_args()
    
    if args.cmd == "hash":
        print(calculate_hash(args.file))
    
    elif args.cmd == "verify":
        if verify_skill(args.file, args.expected_hash):
            print("✓ Verified")
        else:
            print("❌ Hash mismatch")
            exit(1)
    
    elif args.cmd == "register":
        entry = register_skill(args.name, args.file)
        print(f"✓ Registered: {entry['name']} ({entry['hash'][:16]}...)")
    
    elif args.cmd == "list":
        skills = list_skills()
        if not skills:
            print("No skills registered")
        else:
            for s in skills:
                print(f"• {s['name']}: {s['hash'][:16]}... (installed {s['installed_at'][:10]})")
    
    elif args.cmd == "check":
        results = verify_all_skills()
        for r in results:
            status = "✓" if r["status"] == "verified" else "❌"
            print(f"{status} {r['name']}: {r['message']}")
    
    elif args.cmd == "verify-installer":
        valid, messages = verify_installer_files(args.dir)
        for msg in messages:
            print(msg)
        exit(0 if valid else 1)
    
    else:
        parser.print_help()
