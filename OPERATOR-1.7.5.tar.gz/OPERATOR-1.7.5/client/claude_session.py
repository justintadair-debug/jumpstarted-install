#!/usr/bin/env python3
"""
Claude Session Manager — Extracts and manages Claude CLI credentials for background services.

Problem: Claude CLI stores auth in macOS Keychain. Background services (LaunchAgents) can't 
access Keychain without user interaction. This module extracts credentials during interactive
setup and saves them to a file that background services can read.

Usage:
    from claude_session import extract_session, get_session, refresh_session_if_needed
"""

import json
import os
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

# Paths
OPERATOR_DIR = Path.home() / ".operator"
SESSION_FILE = OPERATOR_DIR / "claude-session.json"
KEYCHAIN_SERVICE = "Claude Code-credentials"

# Token refresh buffer (refresh 1 hour before expiry)
REFRESH_BUFFER_MS = 60 * 60 * 1000  # 1 hour in ms


def extract_session() -> Optional[dict]:
    """Extract Claude session from Keychain.
    
    Must be run interactively while user is at keyboard.
    Returns the session dict or None if not found.
    """
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True, text=True, timeout=10
        )
        
        if result.returncode != 0:
            return None
        
        credentials = json.loads(result.stdout.strip())
        return credentials
    except Exception as e:
        print(f"Error extracting session: {e}")
        return None


def save_session(session: dict) -> bool:
    """Save session to file for background service access.
    
    Args:
        session: The Claude credentials dict from Keychain
        
    Returns:
        True if saved successfully
    """
    try:
        OPERATOR_DIR.mkdir(parents=True, exist_ok=True)
        
        # Add extraction timestamp
        session["_extracted_at"] = datetime.now().isoformat()
        session["_source"] = "keychain_extraction"
        
        with open(SESSION_FILE, "w") as f:
            json.dump(session, f, indent=2)
        
        # Secure permissions (owner read/write only)
        os.chmod(SESSION_FILE, 0o600)
        
        return True
    except Exception as e:
        print(f"Error saving session: {e}")
        return False


def get_session() -> Optional[dict]:
    """Get saved session from file.
    
    Returns:
        Session dict or None if not found/invalid
    """
    if not SESSION_FILE.exists():
        return None
    
    try:
        with open(SESSION_FILE) as f:
            return json.load(f)
    except Exception:
        return None


def is_session_valid(session: dict) -> bool:
    """Check if session is still valid (not expired).
    
    Args:
        session: Session dict with claudeAiOauth
        
    Returns:
        True if session is valid and not expired
    """
    oauth = session.get("claudeAiOauth", {})
    expires_at = oauth.get("expiresAt", 0)
    
    # Check if expired (with buffer)
    now_ms = int(time.time() * 1000)
    return now_ms < (expires_at - REFRESH_BUFFER_MS)


def get_access_token() -> Optional[str]:
    """Get the current access token for API calls.
    
    Returns:
        Access token string or None if unavailable
    """
    session = get_session()
    if not session:
        return None
    
    oauth = session.get("claudeAiOauth", {})
    return oauth.get("accessToken")


def get_subscription_type() -> Optional[str]:
    """Get the subscription type (max, pro, etc.).
    
    Returns:
        Subscription type string or None
    """
    session = get_session()
    if not session:
        return None
    
    oauth = session.get("claudeAiOauth", {})
    return oauth.get("subscriptionType")


def refresh_session_via_keychain() -> Optional[dict]:
    """Refresh session by re-extracting from Keychain.
    
    This only works if user is present and Keychain is accessible.
    For background services, this will fail.
    
    Returns:
        New session dict or None
    """
    session = extract_session()
    if session:
        save_session(session)
    return session


def check_and_warn_expiry() -> dict:
    """Check session expiry and return status.
    
    Returns:
        Dict with:
            - valid: bool
            - expires_in_hours: float or None
            - warning: str or None
    """
    session = get_session()
    if not session:
        return {
            "valid": False,
            "expires_in_hours": None,
            "warning": "No session found. Run setup wizard to configure Claude."
        }
    
    oauth = session.get("claudeAiOauth", {})
    expires_at = oauth.get("expiresAt", 0)
    now_ms = int(time.time() * 1000)
    
    if now_ms >= expires_at:
        return {
            "valid": False,
            "expires_in_hours": 0,
            "warning": "Session expired. Re-run setup wizard to refresh."
        }
    
    expires_in_ms = expires_at - now_ms
    expires_in_hours = expires_in_ms / (1000 * 60 * 60)
    
    if expires_in_hours < 24:
        return {
            "valid": True,
            "expires_in_hours": expires_in_hours,
            "warning": f"Session expires in {expires_in_hours:.1f} hours. Consider refreshing."
        }
    
    return {
        "valid": True,
        "expires_in_hours": expires_in_hours,
        "warning": None
    }


def setup_claude_max_session() -> bool:
    """Interactive setup for Claude Max plan.
    
    Extracts credentials from Keychain and saves to file.
    Must be run while user is at keyboard.
    
    Returns:
        True if successful
    """
    print("Extracting Claude session from Keychain...")
    
    session = extract_session()
    if not session:
        print("Could not find Claude credentials in Keychain.")
        print("Make sure you've logged into Claude CLI:")
        print("  1. Run: claude")
        print("  2. Complete the login flow")
        print("  3. Run this setup again")
        return False
    
    # Validate session structure
    oauth = session.get("claudeAiOauth", {})
    if not oauth.get("accessToken"):
        print("Invalid session format. Please re-login to Claude CLI.")
        return False
    
    # Check subscription
    sub_type = oauth.get("subscriptionType", "unknown")
    print(f"Found {sub_type} subscription")
    
    # Save to file
    if save_session(session):
        print(f"Session saved to {SESSION_FILE}")
        
        # Show expiry info
        status = check_and_warn_expiry()
        if status["expires_in_hours"]:
            print(f"Session valid for {status['expires_in_hours']:.1f} hours")
        
        return True
    
    return False


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "extract":
            # Extract and save session
            if setup_claude_max_session():
                print("\n✓ Claude Max session configured for background use")
            else:
                print("\n✗ Failed to configure session")
                sys.exit(1)
        
        elif cmd == "status":
            # Show session status
            status = check_and_warn_expiry()
            if status["valid"]:
                print(f"✓ Session valid ({status['expires_in_hours']:.1f} hours remaining)")
            else:
                print(f"✗ {status['warning']}")
                sys.exit(1)
        
        elif cmd == "token":
            # Print access token (for testing)
            token = get_access_token()
            if token:
                print(token[:20] + "..." + token[-10:])
            else:
                print("No token available")
                sys.exit(1)
        
        else:
            print(f"Unknown command: {cmd}")
            print("Usage: claude_session.py [extract|status|token]")
            sys.exit(1)
    else:
        # Default: show status
        status = check_and_warn_expiry()
        print(json.dumps(status, indent=2))
