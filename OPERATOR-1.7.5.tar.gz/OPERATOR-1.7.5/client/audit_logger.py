#!/usr/bin/env python3
"""
OPERATOR Agent Action Audit Logger.

Logs all agent actions for security and transparency.
Append-only log at ~/.operator/audit.log
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Literal

# Paths
OPERATOR_DIR = Path.home() / ".operator"
AUDIT_LOG = OPERATOR_DIR / "audit.log"

# Action types
ACTION_TYPES = {
    "FILE_READ",
    "FILE_WRITE", 
    "FILE_DELETE",
    "COMMAND_RUN",
    "MESSAGE_SEND",
    "API_CALL",
    "PR_SUBMIT",
    "CRON_CREATE",
    "CRON_DELETE",
    "SKILL_INSTALL",
    "SKILL_UNINSTALL",
    "CONSENT_REQUEST",
    "CONSENT_GRANTED",
    "CONSENT_DENIED",
    "STARTUP",
    "SHUTDOWN",
    "CONFIG_CHANGE",
    "CAPABILITY_UPGRADE",
    "CAPABILITY_DOWNGRADE",
}

# Irreversible actions (require special handling)
IRREVERSIBLE_ACTIONS = {
    "FILE_DELETE",
    "PR_SUBMIT",
    "MESSAGE_SEND",  # External messages
    "CRON_DELETE",
}


def log_action(
    agent: str,
    action_type: str,
    target: str,
    result: str = "success",
    reversible: bool = True,
    details: Optional[dict] = None,
) -> str:
    """Log an agent action to the audit log.
    
    Args:
        agent: Name of the agent (e.g., "neo", "morpheus")
        action_type: Type of action (FILE_WRITE, COMMAND_RUN, etc.)
        target: Target of the action (file path, command, channel, etc.)
        result: Outcome ("success", "error", "denied", etc.)
        reversible: Whether the action can be undone
        details: Optional additional details dict
        
    Returns:
        The formatted log entry
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    
    # Build log entry
    entry_parts = [
        f"[{timestamp}]",
        f"[{agent.upper()}]",
        action_type,
        f"target={_escape(target)}",
        f"result={result}",
    ]
    
    if not reversible:
        entry_parts.append("IRREVERSIBLE")
    
    if details:
        for key, value in details.items():
            entry_parts.append(f"{key}={_escape(str(value))}")
    
    entry = " ".join(entry_parts) + "\n"
    
    # Append to log
    _ensure_log_dir()
    with open(AUDIT_LOG, "a") as f:
        f.write(entry)
    
    return entry.strip()


def log_startup(agent: str, version: str) -> str:
    """Log agent startup event."""
    return log_action(
        agent=agent,
        action_type="STARTUP",
        target="gateway",
        result="success",
        details={"version": version}
    )


def log_shutdown(agent: str, reason: str = "normal") -> str:
    """Log agent shutdown event."""
    return log_action(
        agent=agent,
        action_type="SHUTDOWN",
        target="gateway",
        result=reason,
    )


def log_file_operation(
    agent: str,
    operation: Literal["read", "write", "delete"],
    file_path: str,
    result: str = "success",
    bytes_count: Optional[int] = None,
) -> str:
    """Log a file operation."""
    action_type = {
        "read": "FILE_READ",
        "write": "FILE_WRITE",
        "delete": "FILE_DELETE",
    }[operation]
    
    details = {}
    if bytes_count is not None:
        details["bytes"] = bytes_count
    
    return log_action(
        agent=agent,
        action_type=action_type,
        target=file_path,
        result=result,
        reversible=(operation != "delete"),
        details=details if details else None,
    )


def log_command(
    agent: str,
    command: str,
    result: str = "success",
    exit_code: Optional[int] = None,
) -> str:
    """Log a command execution."""
    details = {}
    if exit_code is not None:
        details["exit_code"] = exit_code
    
    return log_action(
        agent=agent,
        action_type="COMMAND_RUN",
        target=command[:200],  # Truncate long commands
        result=result,
        details=details if details else None,
    )


def log_message(
    agent: str,
    channel: str,
    recipient: str,
    result: str = "success",
) -> str:
    """Log a message send."""
    return log_action(
        agent=agent,
        action_type="MESSAGE_SEND",
        target=f"{channel}:{recipient}",
        result=result,
        reversible=False,
    )


def log_pr_submit(
    agent: str,
    repo: str,
    pr_number: int,
    result: str = "success",
) -> str:
    """Log a PR submission."""
    return log_action(
        agent=agent,
        action_type="PR_SUBMIT",
        target=f"{repo}#{pr_number}",
        result=result,
        reversible=False,
    )


def log_consent(
    agent: str,
    action_requested: str,
    description: str,
    outcome: Literal["granted", "denied", "timeout"],
    approver: Optional[str] = None,
) -> str:
    """Log a consent request and outcome."""
    action_type = {
        "granted": "CONSENT_GRANTED",
        "denied": "CONSENT_DENIED",
        "timeout": "CONSENT_DENIED",
    }[outcome]
    
    details = {"requested_action": action_requested}
    if approver:
        details["approver"] = approver
    
    return log_action(
        agent=agent,
        action_type=action_type,
        target=description[:100],
        result=outcome,
        details=details,
    )


def get_recent_entries(limit: int = 100) -> list[dict]:
    """Get recent audit log entries.
    
    Args:
        limit: Maximum number of entries to return
        
    Returns:
        List of parsed log entries, newest first
    """
    if not AUDIT_LOG.exists():
        return []
    
    entries = []
    with open(AUDIT_LOG) as f:
        lines = f.readlines()
    
    # Parse from newest to oldest
    for line in reversed(lines[-limit:]):
        line = line.strip()
        if not line:
            continue
        
        entry = _parse_log_entry(line)
        if entry:
            entries.append(entry)
    
    return entries


def get_entries_for_agent(agent: str, limit: int = 50) -> list[dict]:
    """Get audit log entries for a specific agent."""
    all_entries = get_recent_entries(limit=500)
    return [e for e in all_entries if e.get("agent", "").lower() == agent.lower()][:limit]


def is_irreversible(action_type: str) -> bool:
    """Check if an action type is irreversible."""
    return action_type in IRREVERSIBLE_ACTIONS


# ── Internal helpers ─────────────────────────────────────────────────────────

def _ensure_log_dir() -> None:
    """Ensure the log directory exists."""
    OPERATOR_DIR.mkdir(parents=True, exist_ok=True)


def _escape(s: str) -> str:
    """Escape special characters for log format."""
    return s.replace(" ", "_").replace("\n", "\\n").replace("\t", "\\t")


def _parse_log_entry(line: str) -> Optional[dict]:
    """Parse a log line into a structured dict."""
    try:
        # Format: [timestamp] [AGENT] ACTION key=value key=value ...
        parts = line.split("]", 2)
        if len(parts) < 3:
            return None
        
        timestamp = parts[0].strip("[")
        agent = parts[1].strip().strip("[")
        
        rest = parts[2].strip().split()
        if not rest:
            return None
        
        action_type = rest[0]
        
        # Parse key=value pairs
        details = {}
        for part in rest[1:]:
            if "=" in part:
                key, value = part.split("=", 1)
                details[key] = value
        
        return {
            "timestamp": timestamp,
            "agent": agent,
            "action": action_type,
            "target": details.get("target", ""),
            "result": details.get("result", ""),
            "irreversible": "IRREVERSIBLE" in line,
            "details": details,
        }
    except Exception:
        return None


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="OPERATOR Audit Logger")
    sub = parser.add_subparsers(dest="cmd")
    
    # log
    p_log = sub.add_parser("log", help="Log an action")
    p_log.add_argument("--agent", required=True)
    p_log.add_argument("--action", required=True)
    p_log.add_argument("--target", required=True)
    p_log.add_argument("--result", default="success")
    
    # recent
    p_recent = sub.add_parser("recent", help="Show recent entries")
    p_recent.add_argument("--limit", type=int, default=20)
    p_recent.add_argument("--agent", default=None)
    
    # tail
    p_tail = sub.add_parser("tail", help="Tail the audit log")
    p_tail.add_argument("-n", type=int, default=10)
    
    args = parser.parse_args()
    
    if args.cmd == "log":
        entry = log_action(args.agent, args.action, args.target, args.result)
        print(entry)
    
    elif args.cmd == "recent":
        if args.agent:
            entries = get_entries_for_agent(args.agent, args.limit)
        else:
            entries = get_recent_entries(args.limit)
        
        for e in entries:
            status = "🔴" if e.get("irreversible") else ("✅" if e.get("result") == "success" else "⚠️")
            print(f"{status} [{e['timestamp'][:19]}] {e['agent']}: {e['action']} → {e['target'][:50]}")
    
    elif args.cmd == "tail":
        if AUDIT_LOG.exists():
            with open(AUDIT_LOG) as f:
                lines = f.readlines()
            for line in lines[-args.n:]:
                print(line.strip())
        else:
            print("No audit log yet")
    
    else:
        parser.print_help()
