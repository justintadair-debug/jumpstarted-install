"""OPERATOR Capability Manager — handles capability levels, upgrades, and kill switch.

Capability Levels:
- Level 1 (Safe Mode): Chat, reminders, web search only
- Level 2 (Extended Access): + sandboxed folder, approved channels, whitelisted commands
- Level 3 (Full Power): Unrestricted access (advanced users only)
"""

import json
import os
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional, Union


# Paths
CONFIG_PATH = Path(os.path.expanduser("~/.operator/config.json"))
AUDIT_LOG_PATH = Path(os.path.expanduser("~/.operator/audit.log"))
WORKSPACE_PATH = Path(os.path.expanduser("~/operator-workspace"))

# Capability level constants
LEVEL_SAFE_MODE = 1
LEVEL_EXTENDED_ACCESS = 2
LEVEL_FULL_POWER = 3

# Level descriptions
LEVEL_NAMES = {
    1: "Safe Mode",
    2: "Extended Access",
    3: "Full Power",
}

# Minimum days on Level 2 before Level 3 unlock
LEVEL_3_WAITING_PERIOD_DAYS = 7

# Upgrade acknowledgment phrases
UPGRADE_PHRASES = {
    2: "I understand, enable extended access",
    3: "I accept full responsibility for my OPERATOR agent",
}


class CapabilityError(Exception):
    """Raised when an action requires a higher capability level."""
    pass


def load_config() -> dict:
    """Load OPERATOR config."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def save_config(config: dict) -> None:
    """Save OPERATOR config."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)


def log_audit(event: str, details: dict) -> None:
    """Append an audit log entry."""
    AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": event,
        **details
    }
    with open(AUDIT_LOG_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")


def get_current_level() -> int:
    """Get the current capability level (defaults to 1)."""
    config = load_config()
    return config.get("capability_level", LEVEL_SAFE_MODE)


def get_level_name(level: int) -> str:
    """Get the display name for a capability level."""
    return LEVEL_NAMES.get(level, f"Level {level}")


def require_capability(required_level: int, action: str) -> None:
    """Check if the current capability level allows an action.
    
    Raises CapabilityError if the action requires a higher level.
    """
    current = get_current_level()
    if current < required_level:
        raise CapabilityError(
            f"Action '{action}' requires {get_level_name(required_level)}. "
            f"Current: {get_level_name(current)}. "
            f"Type '/operator upgrade' to enable."
        )


def can_access_path(path: Union[str, Path]) -> bool:
    """Check if the current capability level allows access to a path."""
    level = get_current_level()
    path = Path(path).expanduser().resolve()
    
    if level == LEVEL_SAFE_MODE:
        # Level 1: No file system access
        return False
    
    if level == LEVEL_EXTENDED_ACCESS:
        # Level 2: Only ~/operator-workspace/
        workspace = WORKSPACE_PATH.resolve()
        try:
            path.relative_to(workspace)
            return True
        except ValueError:
            return False
    
    # Level 3: Full access
    return True


def is_command_approved(command: str) -> bool:
    """Check if a shell command is on the approved whitelist."""
    level = get_current_level()
    
    if level == LEVEL_SAFE_MODE:
        # Level 1: No commands
        return False
    
    if level == LEVEL_FULL_POWER:
        # Level 3: All commands
        return True
    
    # Level 2: Check whitelist
    config = load_config()
    approved = config.get("approved_commands", [])
    
    # Check if command starts with any approved command
    cmd_base = command.split()[0] if command else ""
    return cmd_base in approved


def is_channel_approved(channel_id: str) -> bool:
    """Check if a messaging channel is approved for sending."""
    level = get_current_level()
    
    if level == LEVEL_SAFE_MODE:
        # Level 1: No autonomous sending
        return False
    
    if level == LEVEL_FULL_POWER:
        # Level 3: All channels
        return True
    
    # Level 2: Check approved list
    config = load_config()
    approved = config.get("approved_channels", [])
    return channel_id in approved


def get_status() -> dict:
    """Get current capability status."""
    config = load_config()
    level = config.get("capability_level", LEVEL_SAFE_MODE)
    history = config.get("capability_history", [])
    
    # Calculate days on current level
    days_on_level = 0
    if history:
        last_change = history[-1]
        set_at = datetime.fromisoformat(last_change["set_at"].replace("Z", "+00:00"))
        days_on_level = (datetime.now(timezone.utc) - set_at).days
    
    return {
        "level": level,
        "level_name": get_level_name(level),
        "days_on_level": days_on_level,
        "approved_channels": config.get("approved_channels", []),
        "approved_commands": config.get("approved_commands", []),
        "can_upgrade_to_3": level == LEVEL_EXTENDED_ACCESS and days_on_level >= LEVEL_3_WAITING_PERIOD_DAYS,
    }


def can_upgrade_to(target_level: int) -> tuple[bool, str]:
    """Check if upgrade to target level is allowed.
    
    Returns (allowed, reason).
    """
    current = get_current_level()
    
    if target_level <= current:
        return False, f"Already at {get_level_name(current)}"
    
    if target_level > current + 1:
        return False, f"Can only upgrade one level at a time"
    
    if target_level == LEVEL_FULL_POWER:
        # Check waiting period
        config = load_config()
        history = config.get("capability_history", [])
        
        if current != LEVEL_EXTENDED_ACCESS:
            return False, "Must be on Extended Access before upgrading to Full Power"
        
        # Find when Level 2 was enabled
        level_2_set_at = None
        for entry in reversed(history):
            if entry.get("level") == LEVEL_EXTENDED_ACCESS:
                level_2_set_at = datetime.fromisoformat(entry["set_at"].replace("Z", "+00:00"))
                break
        
        if not level_2_set_at:
            return False, "Extended Access history not found"
        
        days_on_level_2 = (datetime.now(timezone.utc) - level_2_set_at).days
        if days_on_level_2 < LEVEL_3_WAITING_PERIOD_DAYS:
            remaining = LEVEL_3_WAITING_PERIOD_DAYS - days_on_level_2
            return False, f"Must be on Extended Access for {LEVEL_3_WAITING_PERIOD_DAYS} days. {remaining} day(s) remaining."
    
    return True, ""


def get_upgrade_disclosure(target_level: int) -> str:
    """Get the disclosure text for upgrading to a level."""
    if target_level == LEVEL_EXTENDED_ACCESS:
        return """⚠️ EXTENDED ACCESS

This upgrade enables:
• Read/write access to ~/operator-workspace/
• Sending messages to channels you approve
• Running pre-approved shell commands
• Storing API keys in encrypted local config

What's still off-limits:
• Access outside ~/operator-workspace/
• Sending to unapproved channels
• Running arbitrary shell commands

You are responsible for reviewing what your agent sends.

To confirm, type exactly:
  I understand, enable extended access

To cancel, type: cancel"""
    
    elif target_level == LEVEL_FULL_POWER:
        return """🚨 WARNING — FULL POWER MODE

This gives your agent UNRESTRICTED access to:
• Your entire file system
• Your terminal (any command)
• All connected services and APIs

If your agent makes a mistake at this level, the consequences are REAL.
There is no safety net. You are fully responsible.

To confirm, type exactly:
  I accept full responsibility for my OPERATOR agent

You have 60 seconds to confirm. To cancel, type: cancel"""
    
    return ""


def get_install_disclosure() -> str:
    """Get the disclosure text shown at install completion."""
    return """✅ OPERATOR INSTALLED — SAFE MODE

Your agent is running in Safe Mode. It can:
• Chat and answer questions
• Set reminders and crons
• Search the web
• Read files you paste in chat

It CANNOT:
• Access your files autonomously
• Send messages on your behalf
• Run commands on your computer
• Store credentials or API keys

This is intentional — you're in control.

Type '/operator upgrade' to enable more capabilities.
Type '/operator status' to see current settings."""


def upgrade_to(target_level: int, acknowledgment: str) -> tuple[bool, str]:
    """Attempt to upgrade to target level.
    
    Args:
        target_level: The level to upgrade to
        acknowledgment: The exact phrase the user typed
        
    Returns (success, message).
    """
    # Check if upgrade is allowed
    allowed, reason = can_upgrade_to(target_level)
    if not allowed:
        return False, reason
    
    # Check acknowledgment phrase
    required_phrase = UPGRADE_PHRASES.get(target_level, "")
    if acknowledgment.strip().lower() != required_phrase.lower():
        return False, f"Incorrect phrase. Please type exactly: {required_phrase}"
    
    # Perform upgrade
    config = load_config()
    old_level = config.get("capability_level", LEVEL_SAFE_MODE)
    
    config["capability_level"] = target_level
    
    # Add to history
    if "capability_history" not in config:
        config["capability_history"] = []
    config["capability_history"].append({
        "level": target_level,
        "set_at": datetime.now(timezone.utc).isoformat(),
        "reason": f"user_upgrade_from_{old_level}",
        "acknowledgment": acknowledgment,
    })
    
    save_config(config)
    
    # Create workspace directory for Level 2+
    if target_level >= LEVEL_EXTENDED_ACCESS:
        WORKSPACE_PATH.mkdir(parents=True, exist_ok=True)
    
    # Log audit event
    log_audit("capability_upgrade", {
        "old_level": old_level,
        "new_level": target_level,
        "acknowledgment": acknowledgment,
    })
    
    # Return success message
    if target_level == LEVEL_EXTENDED_ACCESS:
        return True, f"""✅ Extended Access enabled.

Your agent can now:
• Read/write files in ~/operator-workspace/
• Send to approved channels
• Run whitelisted commands

To return to Safe Mode: /operator safe-mode
To see status: /operator status"""
    
    elif target_level == LEVEL_FULL_POWER:
        return True, f"""🚨 Full Power enabled.

Your agent now has unrestricted access.
You are responsible for everything it does.

To return to Safe Mode: /operator safe-mode
To see status: /operator status"""
    
    return True, f"Upgraded to {get_level_name(target_level)}"


def downgrade_to_safe_mode() -> str:
    """Immediately drop back to Safe Mode (Level 1)."""
    config = load_config()
    old_level = config.get("capability_level", LEVEL_SAFE_MODE)
    
    if old_level == LEVEL_SAFE_MODE:
        return "Already in Safe Mode."
    
    config["capability_level"] = LEVEL_SAFE_MODE
    
    if "capability_history" not in config:
        config["capability_history"] = []
    config["capability_history"].append({
        "level": LEVEL_SAFE_MODE,
        "set_at": datetime.now(timezone.utc).isoformat(),
        "reason": "user_downgrade",
    })
    
    save_config(config)
    
    log_audit("capability_downgrade", {
        "old_level": old_level,
        "new_level": LEVEL_SAFE_MODE,
        "reason": "user_requested",
    })
    
    return f"""✅ Dropped to Safe Mode.

Your agent can now only:
• Chat and answer questions
• Set reminders
• Search the web

File access, messaging, and commands are disabled."""


def pause_agent() -> str:
    """Pause the agent (stops responding to everything)."""
    config = load_config()
    config["paused"] = True
    config["paused_at"] = datetime.now(timezone.utc).isoformat()
    save_config(config)
    
    log_audit("agent_paused", {})
    
    return "⏸️ OPERATOR paused. Type '/operator resume' to continue."


def resume_agent() -> str:
    """Resume a paused agent."""
    config = load_config()
    if not config.get("paused"):
        return "OPERATOR is not paused."
    
    config["paused"] = False
    config.pop("paused_at", None)
    save_config(config)
    
    log_audit("agent_resumed", {})
    
    return "▶️ OPERATOR resumed."


def is_paused() -> bool:
    """Check if the agent is paused."""
    config = load_config()
    return config.get("paused", False)


def approve_channel(channel_id: str) -> str:
    """Add a channel to the approved list (Level 2+)."""
    level = get_current_level()
    if level < LEVEL_EXTENDED_ACCESS:
        return "Channel approval requires Extended Access. Type '/operator upgrade' first."
    
    config = load_config()
    if "approved_channels" not in config:
        config["approved_channels"] = []
    
    if channel_id in config["approved_channels"]:
        return f"Channel {channel_id} is already approved."
    
    config["approved_channels"].append(channel_id)
    save_config(config)
    
    log_audit("channel_approved", {"channel_id": channel_id})
    
    return f"✅ Channel {channel_id} approved for messaging."


def approve_command(command: str) -> str:
    """Add a command to the approved whitelist (Level 2+)."""
    level = get_current_level()
    if level < LEVEL_EXTENDED_ACCESS:
        return "Command approval requires Extended Access. Type '/operator upgrade' first."
    
    # Extract base command
    cmd_base = command.split()[0] if command else ""
    if not cmd_base:
        return "Invalid command."
    
    config = load_config()
    if "approved_commands" not in config:
        config["approved_commands"] = []
    
    if cmd_base in config["approved_commands"]:
        return f"Command '{cmd_base}' is already approved."
    
    config["approved_commands"].append(cmd_base)
    save_config(config)
    
    log_audit("command_approved", {"command": cmd_base})
    
    return f"✅ Command '{cmd_base}' approved for execution."


def init_capability_on_upgrade() -> str:
    """Initialize capability level for existing installs upgrading from v1.0.x.
    
    Called on first startup after upgrade. Returns notice if one is needed.
    """
    config = load_config()
    
    # Check if capability_level already exists
    if "capability_level" in config:
        return ""  # Already initialized
    
    # Set default to Safe Mode
    config["capability_level"] = LEVEL_SAFE_MODE
    config["capability_history"] = [{
        "level": LEVEL_SAFE_MODE,
        "set_at": datetime.now(timezone.utc).isoformat(),
        "reason": "v1.1_upgrade_default",
    }]
    save_config(config)
    
    log_audit("capability_initialized", {
        "reason": "v1.1_upgrade",
        "default_level": LEVEL_SAFE_MODE,
    })
    
    return """📢 OPERATOR v1.1 — Capability Levels Introduced

For safety, your agent has been set to Safe Mode (Level 1).

In Safe Mode, your agent can:
• Chat and answer questions
• Set reminders
• Search the web

It CANNOT access files, send messages, or run commands.

Type '/operator upgrade' to enable more capabilities.
Type '/operator status' to see current settings."""
