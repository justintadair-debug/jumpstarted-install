"""
OPERATOR LLM Router
Routes tasks between BitNet (local, free, private) and Claude (cloud, paid).

BitNet is used for lightweight background tasks when available.
Claude is the default for complex agent work.

Usage:
    from llm_router import route, bitnet_available
    result = route("summarize", "Summarize: ...")
    print(result["response"], result["model"])
"""

import subprocess
import json
import os
import time
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Paths — check both OPERATOR-managed and manually-installed locations
_BITNET_CANDIDATES = [
    Path.home() / ".operator" / "bitnet",   # OPERATOR-managed (setup_wizard install)
    Path.home() / "projects" / "bitnet",    # Manual install / dev fallback
]


def _get_bitnet_dir() -> Optional[Path]:
    """Return the first BitNet installation directory found."""
    for candidate in _BITNET_CANDIDATES:
        if (candidate / "build" / "bin" / "llama-cli").exists():
            return candidate
    return None


# Convenience properties resolved at call time
def _get_prop(subpath: str) -> Optional[Path]:
    d = _get_bitnet_dir()
    return (d / subpath) if d else None


CLAUDE_WRAPPER = "/Users/justinadair/bin/claude-wrapper"


# Task types suitable for BitNet (lightweight, formatting, summaries)
# These don't need Claude-level intelligence
LIGHTWEIGHT_TASKS = {
    "heartbeat",
    "health_check",
    "log_parse",
    "template_fill",
    "format_status",
    "web_scrape_summary",
    "summarize",
    "status_report",
    "format_output",
    "classify",
    "extract_keywords",
}

# Task types that MUST use Claude (complex reasoning, code, tool use)
CLOUD_REQUIRED_TASKS = {
    "code_generation",
    "code_review",
    "research",
    "planning",
    "multi_step",
    "tool_use",
    "agent_decision",
    "write_post",
    "write_email",
    "analysis",
}

CLAUDE_WRAPPER = "/Users/justinadair/bin/claude-wrapper"


def _find_model() -> Optional[Path]:
    """Find the best available BitNet model file."""
    d = _get_bitnet_dir()
    if d is None:
        return None
    # Check standard model locations
    candidates = [
        d / "models" / "BitNet-b1.58-2B-4T" / "ggml-model-tl1.gguf",
        d / "models" / "BitNet-b1.58-2B-4T" / "ggml-model-i2_s.gguf",
        d / "models" / "bitnet_b1_58-large" / "ggml-model-tl1.gguf",
        d / "models" / "bitnet_b1_58-large" / "ggml-model-i2_s.gguf",
    ]
    for path in candidates:
        if path.exists() and path.stat().st_size > 1_000_000:  # >1MB sanity check
            return path
    return None


def bitnet_available() -> bool:
    """
    Check if BitNet is installed and ready to use.
    Returns True only if both the binary and model are present.
    """
    d = _get_bitnet_dir()
    if d is None:
        return False
    binary = d / "build" / "bin" / "llama-cli"
    run_script = d / "run_inference.py"
    if not binary.exists() or not run_script.exists():
        return False
    model = _find_model()
    return model is not None


def bitnet_inference(prompt: str, max_tokens: int = 200, timeout_sec: int = 60) -> Optional[str]:
    """
    Run inference via BitNet local model.
    Returns the model output string, or None on failure.
    """
    model_path = _find_model()
    if model_path is None:
        logger.warning("BitNet: no model file found")
        return None

    d = _get_bitnet_dir()
    venv_python = d / ".venv" / "bin" / "python"
    run_script = d / "run_inference.py"

    try:
        env = {
            **os.environ,
            "PATH": f"/opt/homebrew/opt/llvm/bin:{os.environ.get('PATH', '')}",
        }
        result = subprocess.run(
            [
                str(venv_python),
                str(run_script),
                "-m", str(model_path),
                "-p", prompt,
                "-n", str(max_tokens),
                "-t", "4",  # 4 threads — good for M4
            ],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            cwd=str(d),
            env=env,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
        if result.stderr:
            logger.debug(f"BitNet stderr: {result.stderr[:200]}")
        return None
    except subprocess.TimeoutExpired:
        logger.warning("BitNet inference timed out")
        return None
    except Exception as e:
        logger.warning(f"BitNet inference error: {e}")
        return None


def claude_inference(prompt: str, timeout_sec: int = 120) -> str:
    """
    Run inference via claude-wrapper.
    Falls back to a placeholder if wrapper not available.
    """
    try:
        result = subprocess.run(
            [CLAUDE_WRAPPER, "-p", prompt],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        return result.stdout.strip()
    except FileNotFoundError:
        return f"[claude-wrapper not found at {CLAUDE_WRAPPER}]"
    except subprocess.TimeoutExpired:
        return "[claude-wrapper timed out]"
    except Exception as e:
        return f"[claude-wrapper error: {e}]"


def route(
    task_type: str,
    prompt: str,
    force_cloud: bool = False,
    max_tokens: int = 200,
) -> dict:
    """
    Route a task to BitNet (local) or Claude (cloud) based on task type and availability.

    Args:
        task_type: Type of task (see LIGHTWEIGHT_TASKS / CLOUD_REQUIRED_TASKS)
        prompt: The prompt to send to the model
        force_cloud: If True, always use Claude regardless of task type
        max_tokens: Max tokens to generate (BitNet only; Claude ignores this)

    Returns:
        {
            "response": str,
            "model": "bitnet" | "claude" | "claude (bitnet fallback)",
            "latency_ms": int,
            "task_type": str,
            "engine": "local" | "cloud",
        }
    """
    start = time.time()

    # Determine if this task is suitable for BitNet
    is_lightweight = task_type in LIGHTWEIGHT_TASKS
    is_cloud_required = task_type in CLOUD_REQUIRED_TASKS or force_cloud
    use_bitnet = is_lightweight and not is_cloud_required and bitnet_available()

    if use_bitnet:
        response = bitnet_inference(prompt, max_tokens=max_tokens)
        if response is None:
            # Fallback to Claude
            response = claude_inference(prompt)
            model = "claude (bitnet fallback)"
            engine = "cloud"
        else:
            model = "bitnet"
            engine = "local"
    else:
        response = claude_inference(prompt)
        model = "claude"
        engine = "cloud"

    latency_ms = int((time.time() - start) * 1000)

    return {
        "response": response,
        "model": model,
        "engine": engine,
        "latency_ms": latency_ms,
        "task_type": task_type,
    }


def get_status() -> dict:
    """Get status info about the LLM router — for OPERATOR dashboard."""
    d = _get_bitnet_dir()
    model = _find_model()
    binary = (d / "build" / "bin" / "llama-cli") if d else None

    return {
        "bitnet_available": bitnet_available(),
        "bitnet_dir": str(d) if d else None,
        "bitnet_binary": str(binary) if binary and binary.exists() else None,
        "bitnet_model": str(model) if model else None,
        "bitnet_model_size_mb": round(model.stat().st_size / 1_000_000, 1) if model else None,
        "claude_wrapper": CLAUDE_WRAPPER,
        "claude_wrapper_available": Path(CLAUDE_WRAPPER).exists(),
        "lightweight_tasks": sorted(LIGHTWEIGHT_TASKS),
        "cloud_required_tasks": sorted(CLOUD_REQUIRED_TASKS),
    }


if __name__ == "__main__":
    import sys

    print("=== OPERATOR LLM Router Status ===")
    status = get_status()
    for k, v in status.items():
        if isinstance(v, list):
            print(f"  {k}: {', '.join(v[:5])}{'...' if len(v) > 5 else ''}")
        else:
            print(f"  {k}: {v}")

    print("\n=== Routing Test ===")
    test_prompt = "Summarize in one sentence: The quick brown fox jumps over the lazy dog."

    # Test lightweight routing
    result = route("summarize", test_prompt)
    print(f"Task: summarize → Model: {result['model']} | Latency: {result['latency_ms']}ms")
    print(f"Response: {result['response'][:100]}...")

    # Test cloud-required routing
    if "--full" in sys.argv:
        result2 = route("code_generation", "Write a Python hello world function.")
        print(f"\nTask: code_generation → Model: {result2['model']} | Latency: {result2['latency_ms']}ms")
        print(f"Response: {result2['response'][:100]}...")
