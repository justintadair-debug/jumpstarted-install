#!/usr/bin/env python3
"""
Claude Environment Exporter — Outputs environment variables for OpenClaw.

Reads the saved Claude session and outputs shell export commands.
Used by LaunchAgent to set ANTHROPIC_OAUTH_TOKEN before starting gateway.
"""

import json
import sys
from pathlib import Path

SESSION_FILE = Path.home() / ".operator" / "claude-session.json"


def get_oauth_token() -> str:
    """Get OAuth token from saved session."""
    if not SESSION_FILE.exists():
        return ""
    
    try:
        with open(SESSION_FILE) as f:
            session = json.load(f)
        
        oauth = session.get("claudeAiOauth", {})
        return oauth.get("accessToken", "")
    except Exception:
        return ""


def main():
    """Output environment export commands."""
    token = get_oauth_token()
    
    if not token:
        print("# No Claude session found", file=sys.stderr)
        sys.exit(1)
    
    # Output in format suitable for eval or sourcing
    print(f'export ANTHROPIC_OAUTH_TOKEN="{token}"')


if __name__ == "__main__":
    main()
