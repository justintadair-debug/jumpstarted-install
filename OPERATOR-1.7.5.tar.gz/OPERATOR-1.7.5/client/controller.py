"""
OPERATOR AIBox Controller
Client-side license validation daemon with offline grace period.
"""

import base64
import json
import os
import sys
import time
import hashlib
import subprocess
import platform
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
import urllib.request
import urllib.error

# === Configuration ===
OPERATOR_DIR = Path.home() / ".operator"
LICENSE_FILE = OPERATOR_DIR / "license.json"
STATE_FILE = OPERATOR_DIR / "state.json"
CONFIG_FILE = OPERATOR_DIR / "config.json"

# Security: License server URL is hardcoded - must not be overridable by environment
LICENSE_SERVER = "https://operator-license-server.fly.dev"
OFFLINE_GRACE_DAYS = 7
VALIDATION_INTERVAL_HOURS = 24


def get_verify_key() -> str:
    """Get the public verification key from env var or config file."""
    # First try environment variable
    key = os.environ.get("OPERATOR_VERIFY_KEY", "")
    if key:
        return key
    
    # Then try config file
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                return config.get("verify_key", "")
        except:
            pass
    
    return ""


def decode_license_key_string(license_key_str: str) -> dict:
    """Decode a base64-encoded license key string (op_live_<base64>)."""
    if not license_key_str.startswith("op_live_"):
        raise ValueError("Invalid license key format - must start with op_live_")
    
    b64_part = license_key_str[8:]  # Remove "op_live_" prefix
    try:
        json_bytes = base64.urlsafe_b64decode(b64_part)
        return json.loads(json_bytes)
    except Exception as e:
        raise ValueError(f"Failed to decode license key: {e}")


def ensure_dirs():
    """Ensure operator directories exist."""
    OPERATOR_DIR.mkdir(exist_ok=True)
    os.chmod(OPERATOR_DIR, 0o700)


def get_hardware_fingerprint() -> str:
    """Generate a hardware fingerprint for this machine."""
    components = []
    
    # Mac serial number
    try:
        result = subprocess.run(
            ["system_profiler", "SPHardwareDataType"],
            capture_output=True, text=True
        )
        for line in result.stdout.split("\n"):
            if "Serial Number" in line:
                components.append(line.split(":")[-1].strip())
                break
    except Exception:
        pass
    
    # Hardware UUID
    try:
        result = subprocess.run(
            ["system_profiler", "SPHardwareDataType"],
            capture_output=True, text=True
        )
        for line in result.stdout.split("\n"):
            if "Hardware UUID" in line:
                components.append(line.split(":")[-1].strip())
                break
    except Exception:
        pass
    
    # Fallback: hostname + username
    if not components:
        components.append(platform.node())
        components.append(os.getlogin())
    
    fingerprint = hashlib.sha256(":".join(components).encode()).hexdigest()[:32]
    return fingerprint


def load_license() -> Optional[str]:
    """Load license key string from file."""
    if LICENSE_FILE.exists():
        with open(LICENSE_FILE) as f:
            data = json.load(f)
            return data.get("license_key")
    return None


def save_license(license_key_str: str):
    """Save license key string to file."""
    ensure_dirs()
    with open(LICENSE_FILE, "w") as f:
        json.dump({"license_key": license_key_str}, f, indent=2)
    os.chmod(LICENSE_FILE, 0o600)


def load_state() -> dict:
    """Load validation state."""
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {
        "last_online_validation": None,
        "last_validation_result": None,
        "offline_since": None,
    }


def save_state(state: dict):
    """Save validation state."""
    ensure_dirs()
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)
    # FIX 16: Secure state file permissions
    os.chmod(STATE_FILE, 0o600)


def verify_signature_offline(license_key_obj: dict) -> bool:
    """Verify license signature offline using public key from config."""
    verify_key_hex = get_verify_key()
    if not verify_key_hex:
        return False  # No key available, can't verify offline
    
    try:
        import nacl.signing
        import nacl.encoding
        
        payload = license_key_obj.get("payload", {})
        signature = license_key_obj.get("signature", "")
        
        verify_key = nacl.signing.VerifyKey(
            verify_key_hex.encode(),
            encoder=nacl.encoding.HexEncoder
        )
        
        payload_bytes = json.dumps(payload, sort_keys=True).encode()
        verify_key.verify(
            payload_bytes,
            nacl.encoding.HexEncoder.decode(signature.encode())
        )
        return True
    except Exception as e:
        print(f"Offline verification failed: {e}")
        return False


def validate_online(license_key_str: str, fingerprint: str) -> dict:
    """Validate license against server."""
    try:
        url = f"{LICENSE_SERVER}/v1/license/validate"
        data = json.dumps({
            "license_key": license_key_str,  # Send the op_live_<base64> string
            "hardware_fingerprint": fingerprint,
        }).encode()
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            return json.loads(body)
        except:
            return {"valid": False, "error": str(e)}
    except Exception as e:
        return {"valid": False, "error": f"Network error: {e}", "offline": True}


def check_revocations(license_id: str) -> bool:
    """Check if license is in revocation list."""
    try:
        url = f"{LICENSE_SERVER}/v1/revocations"
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return license_id in data.get("revoked", [])
    except:
        return False  # Can't check, assume not revoked


class LicenseStatus:
    """License validation result."""
    def __init__(self, valid: bool, tier: str = None, error: str = None,
                 max_agents: int = 0, max_crons: int = 0, grace_period: bool = False):
        self.valid = valid
        self.tier = tier
        self.error = error
        self.max_agents = max_agents
        self.max_crons = max_crons
        self.grace_period = grace_period
    
    def to_dict(self) -> dict:
        return {
            "valid": self.valid,
            "tier": self.tier,
            "error": self.error,
            "max_agents": self.max_agents,
            "max_crons": self.max_crons,
            "grace_period": self.grace_period,
        }


def validate_license() -> LicenseStatus:
    """
    Main validation function.
    Returns LicenseStatus with validation result.
    """
    license_key_str = load_license()
    if not license_key_str:
        return LicenseStatus(False, error="No license file found")
    
    # Decode the license key string to get payload for local checks
    try:
        license_key_obj = decode_license_key_string(license_key_str)
    except ValueError as e:
        return LicenseStatus(False, error=str(e))
    
    state = load_state()
    fingerprint = get_hardware_fingerprint()
    payload = license_key_obj.get("payload", {})
    license_id = payload.get("license_id")
    now = datetime.now(timezone.utc)
    
    # Check local expiration first
    expires_at = payload.get("expires_at")
    if expires_at:
        exp_dt = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        if now > exp_dt:
            return LicenseStatus(False, error="License expired")
    
    # Try online validation (send the string, not the object)
    result = validate_online(license_key_str, fingerprint)
    
    if result.get("offline"):
        # Network unavailable - check grace period
        last_online = state.get("last_online_validation")
        
        if last_online:
            last_dt = datetime.fromisoformat(last_online.replace("Z", "+00:00"))
            grace_end = last_dt + timedelta(days=OFFLINE_GRACE_DAYS)
            
            if now <= grace_end:
                # Within grace period - use last known good state
                last_result = state.get("last_validation_result", {})
                if last_result.get("valid"):
                    # Also verify signature offline
                    if verify_signature_offline(license_key_obj):
                        return LicenseStatus(
                            valid=True,
                            tier=last_result.get("tier"),
                            max_agents=last_result.get("max_agents", 0),
                            max_crons=last_result.get("max_crons", 0),
                            grace_period=True,
                        )
        
        # Offline and no valid grace period
        # Try pure offline validation as last resort
        if verify_signature_offline(license_key_obj):
            return LicenseStatus(
                valid=True,
                tier=payload.get("tier"),
                max_agents=payload.get("max_agents", 0),
                max_crons=payload.get("max_crons", 0),
                grace_period=True,
                error="Operating in offline mode - connect to validate"
            )
        
        return LicenseStatus(False, error="Offline and grace period expired")
    
    # Online validation succeeded or failed
    if result.get("valid"):
        # Update state
        state["last_online_validation"] = now.isoformat()
        state["last_validation_result"] = result
        state["offline_since"] = None
        save_state(state)
        
        return LicenseStatus(
            valid=True,
            tier=result.get("tier"),
            max_agents=result.get("max_agents", 0),
            max_crons=result.get("max_crons", 0),
        )
    else:
        return LicenseStatus(False, error=result.get("error", "Validation failed"))


def activate_license(license_key_str: str) -> LicenseStatus:
    """
    Activate a new license key.
    license_key_str: The op_live_<base64> license key string
    """
    license_key_str = license_key_str.strip()
    
    # Validate the format
    if not license_key_str.startswith("op_live_"):
        return LicenseStatus(False, error="Invalid license key format - must start with op_live_")
    
    # Try to decode it to verify it's valid
    try:
        decode_license_key_string(license_key_str)
    except ValueError as e:
        return LicenseStatus(False, error=str(e))
    
    # Save the license key string
    save_license(license_key_str)
    
    # Reset state
    save_state({
        "last_online_validation": None,
        "last_validation_result": None,
        "offline_since": None,
    })
    
    # Validate immediately
    return validate_license()


def get_status() -> dict:
    """Get current license status and system info."""
    status = validate_license()
    state = load_state()
    
    return {
        "license": status.to_dict(),
        "fingerprint": get_hardware_fingerprint(),
        "last_validation": state.get("last_online_validation"),
        "operator_dir": str(OPERATOR_DIR),
    }


# === CLI Interface ===

def main():
    import argparse
    parser = argparse.ArgumentParser(description="OPERATOR License Controller")
    subparsers = parser.add_subparsers(dest="command")
    
    # status
    subparsers.add_parser("status", help="Show license status")
    
    # activate
    p_activate = subparsers.add_parser("activate", help="Activate a license key")
    p_activate.add_argument("license_key", help="License key JSON (or path to file)")
    
    # validate
    subparsers.add_parser("validate", help="Validate current license")
    
    # fingerprint
    subparsers.add_parser("fingerprint", help="Show hardware fingerprint")
    
    args = parser.parse_args()
    
    if args.command == "status":
        status = get_status()
        print(json.dumps(status, indent=2))
    
    elif args.command == "activate":
        key_input = args.license_key
        if os.path.exists(key_input):
            with open(key_input) as f:
                key_input = f.read()
        
        result = activate_license(key_input)
        if result.valid:
            print(f"✅ License activated successfully!")
            print(f"   Tier: {result.tier}")
            print(f"   Max agents: {result.max_agents}")
            print(f"   Max crons: {result.max_crons}")
        else:
            print(f"❌ Activation failed: {result.error}")
            sys.exit(1)
    
    elif args.command == "validate":
        result = validate_license()
        if result.valid:
            grace_msg = " (grace period)" if result.grace_period else ""
            print(f"✅ License valid{grace_msg}")
            print(f"   Tier: {result.tier}")
        else:
            print(f"❌ License invalid: {result.error}")
            sys.exit(1)
    
    elif args.command == "fingerprint":
        print(get_hardware_fingerprint())
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
