#!/bin/bash
#
# JUMPSTARTED Installer
# Installs JUMPSTARTED AI system on macOS
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# Paths
OPERATOR_HOME="$HOME/.operator"
WORKSPACE="$HOME/operator-workspace"
LAUNCH_AGENT="$HOME/Library/LaunchAgents/com.jumpstarted.agent.plist"

# Version
VERSION="1.5.0"

echo ""
echo -e "${BOLD}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║${NC}   ${BLUE}JUMPSTARTED${NC} Installer v${VERSION}                               ${BOLD}║${NC}"
echo -e "${BOLD}║${NC}   Your AI team, running 24/7.                                ${BOLD}║${NC}"
echo -e "${BOLD}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
# UX FIX 7: Setup time estimate
echo -e "  This takes about 3 minutes. 7 steps."
echo ""

# Check macOS
if [[ "$(uname)" != "Darwin" ]]; then
    echo -e "${RED}Error: JUMPSTARTED requires macOS${NC}"
    exit 1
fi

# Check architecture
ARCH=$(uname -m)
if [[ "$ARCH" != "arm64" ]]; then
    echo -e "${YELLOW}Warning: JUMPSTARTED is optimized for Apple Silicon (M1/M2/M3/M4)${NC}"
    echo -e "${YELLOW}Intel Macs will work but with reduced performance.${NC}"
    read -p "Continue anyway? [y/N] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo -e "${BLUE}Checking prerequisites...${NC}"

# Check for Homebrew
if ! command -v brew &> /dev/null; then
    echo -e "${YELLOW}Homebrew not found. Installing...${NC}"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Add Homebrew to PATH for Apple Silicon
    if [[ "$ARCH" == "arm64" ]]; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
fi
echo -e "${GREEN}✓${NC} Homebrew"

# Check for Node.js
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Node.js not found. Installing...${NC}"
    brew install node
fi
NODE_VERSION=$(node --version)
echo -e "${GREEN}✓${NC} Node.js ${NODE_VERSION}"

# Check for Python 3
if ! command -v python3 &> /dev/null; then
    echo -e "${YELLOW}Python 3 not found. Installing...${NC}"
    brew install python@3.12
fi
PYTHON_VERSION=$(python3 --version)
echo -e "${GREEN}✓${NC} ${PYTHON_VERSION}"

# Check/Install OpenClaw
if ! command -v openclaw &> /dev/null; then
    echo -e "${YELLOW}OpenClaw not found. Installing...${NC}"
    
    # Use user-local npm prefix to avoid permission issues on non-admin Macs
    NPM_PREFIX="$HOME/.npm-global"
    mkdir -p "$NPM_PREFIX"
    npm config set prefix "$NPM_PREFIX"
    
    # Add to PATH for this session
    export PATH="$NPM_PREFIX/bin:$PATH"
    
    # Install OpenClaw to user-local prefix
    npm install -g openclaw
    
    # Ensure PATH is set in shell profile for future sessions
    SHELL_PROFILE=""
    if [[ -f "$HOME/.zshrc" ]]; then
        SHELL_PROFILE="$HOME/.zshrc"
    elif [[ -f "$HOME/.bash_profile" ]]; then
        SHELL_PROFILE="$HOME/.bash_profile"
    elif [[ -f "$HOME/.bashrc" ]]; then
        SHELL_PROFILE="$HOME/.bashrc"
    fi
    
    if [[ -n "$SHELL_PROFILE" ]]; then
        # Only add if not already present
        if ! grep -q 'npm-global/bin' "$SHELL_PROFILE" 2>/dev/null; then
            echo "" >> "$SHELL_PROFILE"
            echo "# Added by JUMPSTARTED installer - npm global packages" >> "$SHELL_PROFILE"
            echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> "$SHELL_PROFILE"
            echo -e "${GREEN}✓${NC} Added npm-global to PATH in $SHELL_PROFILE"
        fi
    fi
fi

# Ensure PATH includes npm-global for this session
export PATH="$HOME/.npm-global/bin:$PATH"

OPENCLAW_VERSION=$(openclaw --version 2>/dev/null || echo "unknown")
echo -e "${GREEN}✓${NC} OpenClaw ${OPENCLAW_VERSION}"

echo ""
echo -e "${BLUE}Installing JUMPSTARTED...${NC}"

# Create directories with secure permissions
mkdir -p "$OPERATOR_HOME"
mkdir -p "$WORKSPACE"
mkdir -p "$OPERATOR_HOME/configs"
mkdir -p "$OPERATOR_HOME/logs"

# Secure log directory permissions
chmod 700 "$OPERATOR_HOME/logs"
touch "$OPERATOR_HOME/logs/operator.log" "$OPERATOR_HOME/logs/operator-error.log"
chmod 600 "$OPERATOR_HOME/logs/operator.log" "$OPERATOR_HOME/logs/operator-error.log"

# Copy configuration files
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -d "$SCRIPT_DIR/configs" ]]; then
    cp -r "$SCRIPT_DIR/configs/"* "$OPERATOR_HOME/configs/"
    echo -e "${GREEN}✓${NC} Configuration files installed"
fi

# Copy client scripts
if [[ -d "$SCRIPT_DIR/client" ]]; then
    cp -r "$SCRIPT_DIR/client/"* "$OPERATOR_HOME/"
    chmod +x "$OPERATOR_HOME/"*.py 2>/dev/null || true
    echo -e "${GREEN}✓${NC} Client scripts installed"
fi

# Install Python dependencies using venv
echo -e "${BLUE}Installing Python dependencies...${NC}"
VENV_DIR="$OPERATOR_HOME/venv"
if [[ ! -d "$VENV_DIR" ]]; then
    python3 -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/pip" install --quiet --upgrade pip
if [[ -f "$SCRIPT_DIR/requirements.txt" ]]; then
    "$VENV_DIR/bin/pip" install --quiet -r "$SCRIPT_DIR/requirements.txt"
else
    "$VENV_DIR/bin/pip" install --quiet "pynacl==1.5.0" "requests==2.31.0"
fi
echo -e "${GREEN}✓${NC} Python dependencies (venv: $VENV_DIR)"

# Create workspace files if they don't exist
if [[ ! -f "$WORKSPACE/AGENTS.md" ]]; then
    cp "$OPERATOR_HOME/configs/starter/AGENTS.md" "$WORKSPACE/"
fi
if [[ ! -f "$WORKSPACE/SOUL.md" ]]; then
    cp "$OPERATOR_HOME/configs/starter/SOUL.md" "$WORKSPACE/"
fi
if [[ ! -f "$WORKSPACE/MEMORY.md" ]]; then
    echo "# Memory" > "$WORKSPACE/MEMORY.md"
    echo "" >> "$WORKSPACE/MEMORY.md"
    echo "This file stores important information across sessions." >> "$WORKSPACE/MEMORY.md"
fi
if [[ ! -f "$WORKSPACE/openclaw.yaml" ]]; then
    cp "$OPERATOR_HOME/configs/starter/openclaw.yaml" "$WORKSPACE/"
fi
if [[ ! -f "$WORKSPACE/openclaw.yaml" ]]; then
    echo -e "${RED}Error: Failed to copy openclaw.yaml to workspace${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} OpenClaw config installed"
echo -e "${GREEN}✓${NC} Workspace initialized at $WORKSPACE"

# Fetch public key from license server
echo -e "${BLUE}Fetching license server public key...${NC}"
# Security: License server URL is hardcoded - must not be overridable by environment
LICENSE_SERVER="https://operator-license-server.fly.dev"
VERIFY_KEY_RESPONSE=$(curl -fsS --connect-timeout 5 "$LICENSE_SERVER/v1/public-key" 2>/dev/null) || VERIFY_KEY_RESPONSE=""
VERIFY_KEY=""
if [[ -n "$VERIFY_KEY_RESPONSE" ]]; then
    VERIFY_KEY=$(echo "$VERIFY_KEY_RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('verify_key',''))" 2>/dev/null || echo "")
fi

if [[ -n "$VERIFY_KEY" ]]; then
    echo "{\"verify_key\": \"$VERIFY_KEY\"}" > "$OPERATOR_HOME/config.json"
    chmod 600 "$OPERATOR_HOME/config.json"
    echo -e "${GREEN}✓${NC} License server public key saved"
else
    echo -e "${YELLOW}!${NC} Could not fetch public key (offline mode will be limited)"
    echo "{}" > "$OPERATOR_HOME/config.json"
fi

# Create jmp CLI wrapper
cat > "$OPERATOR_HOME/jmp" << 'JMP_CLI'
#!/bin/bash
# JUMPSTARTED CLI (jmp)
# Your AI team, running 24/7.

OPERATOR_HOME="$HOME/.operator"
WORKSPACE="$HOME/operator-workspace"

case "$1" in
    start)
        echo "Starting JUMPSTARTED..."
        cd "$WORKSPACE"
        openclaw gateway start
        ;;
    stop)
        echo "Stopping JUMPSTARTED..."
        openclaw gateway stop
        ;;
    status)
        "$OPERATOR_HOME/venv/bin/python3" "$OPERATOR_HOME/controller.py" status
        ;;
    setup)
        "$OPERATOR_HOME/venv/bin/python3" "$OPERATOR_HOME/setup_wizard.py" "${@:2}"
        ;;
    activate)
        "$OPERATOR_HOME/venv/bin/python3" "$OPERATOR_HOME/controller.py" activate "$2"
        ;;
    validate)
        "$OPERATOR_HOME/venv/bin/python3" "$OPERATOR_HOME/controller.py" validate
        ;;
    logs)
        tail -f "$OPERATOR_HOME/logs/operator.log"
        ;;
    *)
        echo "JUMPSTARTED - Your AI team, running 24/7"
        echo ""
        echo "Usage: jmp <command>"
        echo ""
        echo "Commands:"
        echo "  start     Start JUMPSTARTED gateway"
        echo "  stop      Stop JUMPSTARTED gateway"
        echo "  status    Show license and system status"
        echo "  setup     Run the setup wizard"
        echo "  activate  Activate a license key"
        echo "  validate  Validate current license"
        echo "  logs      Follow JUMPSTARTED logs"
        echo ""
        ;;
esac
JMP_CLI

chmod +x "$OPERATOR_HOME/jmp"

# Also create 'operator' alias for backwards compatibility
cp "$OPERATOR_HOME/jmp" "$OPERATOR_HOME/operator"
chmod +x "$OPERATOR_HOME/operator"

# Create symlinks - prefer ~/.local/bin (doesn't require sudo)
mkdir -p "$HOME/.local/bin"
ln -sf "$OPERATOR_HOME/jmp" "$HOME/.local/bin/jmp"
ln -sf "$OPERATOR_HOME/jmp" "$HOME/.local/bin/operator"
echo -e "${GREEN}✓${NC} CLI installed: jmp"

# Ensure ~/.local/bin is in PATH
SHELL_PROFILE=""
if [[ -f "$HOME/.zshrc" ]]; then
    SHELL_PROFILE="$HOME/.zshrc"
elif [[ -f "$HOME/.bash_profile" ]]; then
    SHELL_PROFILE="$HOME/.bash_profile"
fi

if [[ -n "$SHELL_PROFILE" ]]; then
    if ! grep -q '.local/bin' "$SHELL_PROFILE" 2>/dev/null; then
        echo "" >> "$SHELL_PROFILE"
        echo "# Added by JUMPSTARTED installer" >> "$SHELL_PROFILE"
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$SHELL_PROFILE"
    fi
fi

# Add to PATH for this session
export PATH="$HOME/.local/bin:$PATH"

# Create LaunchAgent for auto-start (optional)
mkdir -p "$HOME/Library/LaunchAgents"

cat > "$LAUNCH_AGENT" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.jumpstarted.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>$OPERATOR_HOME/jmp</string>
        <string>start</string>
    </array>
    <key>RunAtLoad</key>
    <false/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardOutPath</key>
    <string>$OPERATOR_HOME/logs/operator.log</string>
    <key>StandardErrorPath</key>
    <string>$OPERATOR_HOME/logs/operator-error.log</string>
    <key>WorkingDirectory</key>
    <string>$WORKSPACE</string>
</dict>
</plist>
PLIST

echo -e "${GREEN}✓${NC} LaunchAgent created (auto-start disabled by default)"

echo ""
echo -e "${GREEN}${BOLD}═══ Installation Complete! ═══${NC}"
echo ""
echo "Next steps:"
echo ""
echo "  1. Run the setup wizard:"
echo -e "     ${BLUE}jmp setup${NC}"
echo ""
echo "  2. Or activate your license manually:"
echo -e "     ${BLUE}jmp activate '<your-license-key>'${NC}"
echo ""
echo "  3. Start JUMPSTARTED:"
echo -e "     ${BLUE}jmp start${NC}"
echo ""
echo "  4. (Optional) Enable auto-start on login:"
echo -e "     ${BLUE}launchctl load $LAUNCH_AGENT${NC}"
echo ""
echo -e "Documentation: ${BLUE}https://docs.jumpstarted.ai${NC}"
echo ""
echo "Thank you for choosing JUMPSTARTED! 🚀"
echo ""

# Ask to run setup wizard
read -p "Run setup wizard now? [Y/n] " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Nn]$ ]]; then
    "$OPERATOR_HOME/venv/bin/python3" "$OPERATOR_HOME/setup_wizard.py"
fi
