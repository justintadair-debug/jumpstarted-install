#!/usr/bin/env python3
"""
JUMPSTARTED Setup Wizard
Interactive CLI to set up JUMPSTARTED for first-time users.
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from getpass import getpass
from datetime import datetime

# Add client module
sys.path.insert(0, str(Path(__file__).parent))
from controller import (
    activate_license, validate_license, get_hardware_fingerprint,
    OPERATOR_DIR, CONFIG_FILE, ensure_dirs
)

# Check if running interactively (stdin is a terminal)
IS_INTERACTIVE = sys.stdin.isatty()

# Colors
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BLUE = "\033[94m"
BOLD = "\033[1m"
RESET = "\033[0m"


def print_header():
    """Print the setup wizard header."""
    print(f"""
{BOLD}╔═══════════════════════════════════════════════════════════════╗
║                                                                   ║
║   {BLUE}JUMPSTARTED{RESET}                                                    ║
║   {GREEN}Your AI team, running 24/7.{RESET}                                    ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
{RESET}""")


def print_step(num: int, total: int, title: str):
    """Print a step header."""
    print(f"\n{BOLD}─── Step {num}/{total}: {title} ───{RESET}\n")


def print_success(msg: str):
    print(f"{GREEN}✓{RESET} {msg}")


def print_error(msg: str):
    print(f"{RED}✗{RESET} {msg}")


def print_info(msg: str):
    print(f"{BLUE}ℹ{RESET} {msg}")


def print_warning(msg: str):
    print(f"{YELLOW}⚠{RESET} {msg}")


def load_config() -> dict:
    """Load existing config."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def save_config(config: dict):
    """Save config to file."""
    ensure_dirs()
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(CONFIG_FILE, 0o600)


# BitNet paths
BITNET_DIR = Path(os.path.expanduser("~/.operator/bitnet"))
BITNET_MODEL = BITNET_DIR / "models" / "bitnet_b1_58-large" / "ggml-model-i2_s.gguf"
BITNET_CLI = BITNET_DIR / "build" / "bin" / "llama-cli"


def _check_bitnet_installed() -> bool:
    """Check if BitNet is installed and ready."""
    if BITNET_MODEL.exists() and BITNET_CLI.exists():
        print_success("BitNet already installed")
        return True
    return False


def _install_bitnet() -> bool:
    """Install BitNet for local inference."""
    print_info("Installing BitNet b1.58 for local AI...")
    print_info("This may take a few minutes.")
    
    try:
        BITNET_DIR.mkdir(parents=True, exist_ok=True)
        
        # Clone BitNet repo
        print_info("Cloning BitNet repository...")
        subprocess.run(
            ["git", "clone", "--depth", "1", "https://github.com/microsoft/BitNet.git", str(BITNET_DIR)],
            check=True,
            capture_output=True
        )
        
        # Clone the correct llama.cpp fork (with TL1 support)
        print_info("Setting up llama.cpp with TL1 support...")
        llama_dir = BITNET_DIR / "3rdparty" / "llama.cpp"
        if llama_dir.exists():
            import shutil
            shutil.rmtree(llama_dir)
        subprocess.run(
            ["git", "clone", "--depth", "1", "-b", "merge-dev", 
             "https://github.com/Eddie-Wang1120/llama.cpp.git", str(llama_dir)],
            check=True,
            capture_output=True
        )
        
        # Create venv and install dependencies
        print_info("Installing Python dependencies...")
        venv_dir = BITNET_DIR / ".venv"
        subprocess.run(["python3", "-m", "venv", str(venv_dir)], check=True, capture_output=True)
        pip = venv_dir / "bin" / "pip"
        subprocess.run([str(pip), "install", str(llama_dir / "gguf-py"), "--no-deps"], 
                      check=True, capture_output=True)
        subprocess.run([str(pip), "install", "torch", "transformers", "numpy"], 
                      check=True, capture_output=True)
        
        # Build with cmake
        print_info("Building BitNet (cmake)...")
        build_dir = BITNET_DIR / "build"
        subprocess.run(
            ["cmake", "-B", str(build_dir), 
             "-DCMAKE_C_COMPILER=clang", "-DCMAKE_CXX_COMPILER=clang++",
             "-DBITNET_ARM_TL1=OFF", "-DLLAMA_BUILD_TOOLS=ON", "-DLLAMA_BUILD_COMMON=ON"],
            cwd=str(BITNET_DIR),
            check=True,
            capture_output=True
        )
        subprocess.run(
            ["cmake", "--build", str(build_dir), "--config", "Release", "-j4"],
            check=True,
            capture_output=True
        )
        
        # Download and convert model
        print_info("Downloading BitNet 0.7B model (~500MB)...")
        models_dir = BITNET_DIR / "models" / "bitnet_b1_58-large"
        models_dir.mkdir(parents=True, exist_ok=True)
        
        python = venv_dir / "bin" / "python"
        subprocess.run(
            [str(python), "-c", f"""
from huggingface_hub import snapshot_download
snapshot_download(repo_id='1bitLLM/bitnet_b1_58-large', local_dir='{models_dir}')
"""],
            check=True,
            capture_output=True
        )
        
        # Convert and quantize
        print_info("Converting model to GGUF format...")
        subprocess.run(
            [str(python), str(BITNET_DIR / "utils" / "convert-hf-to-gguf-bitnet.py"),
             str(models_dir), "--outtype", "f32"],
            check=True,
            capture_output=True
        )
        
        print_info("Quantizing model to I2_S...")
        quantize = build_dir / "bin" / "llama-quantize"
        subprocess.run(
            [str(quantize), str(models_dir / "ggml-model-f32.gguf"),
             str(models_dir / "ggml-model-i2_s.gguf"), "I2_S", "1"],
            check=True,
            capture_output=True
        )
        
        # Clean up f32 model to save space
        f32_model = models_dir / "ggml-model-f32.gguf"
        if f32_model.exists():
            f32_model.unlink()
        
        print_success("BitNet installed successfully!")
        return True
        
    except subprocess.CalledProcessError as e:
        print_error(f"BitNet installation failed: {e}")
        return False
    except Exception as e:
        print_error(f"BitNet installation error: {e}")
        return False


def set_keychain_password(service: str, account: str, password: str) -> bool:
    """Store a password in macOS Keychain."""
    try:
        # Delete existing entry if any
        subprocess.run(
            ["security", "delete-generic-password", "-s", service, "-a", account],
            capture_output=True
        )
        # Add new entry
        result = subprocess.run(
            ["security", "add-generic-password", "-s", service, "-a", account, "-w", password],
            capture_output=True
        )
        return result.returncode == 0
    except Exception as e:
        print_error(f"Keychain error: {e}")
        return False


def get_keychain_password(service: str, account: str) -> str:
    """Get a password from macOS Keychain."""
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-s", service, "-a", account, "-w"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except:
        pass
    return ""


def _find_openclaw_binary() -> str:
    """Find the OpenClaw binary path."""
    import shutil
    
    # Check common locations
    possible_paths = [
        os.path.expanduser("~/.npm-global/bin/openclaw"),
        "/usr/local/bin/openclaw",
        "/opt/homebrew/bin/openclaw",
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            return path
    
    # Check if openclaw is in PATH
    openclaw_in_path = shutil.which("openclaw")
    if openclaw_in_path:
        return openclaw_in_path
    
    return ""


def _write_oauth_to_openclaw_config(oauth_token: str) -> bool:
    """Write OAuth token to OpenClaw's config for background service access.
    
    Sets env.vars.ANTHROPIC_OAUTH_TOKEN in openclaw.json so the gateway
    can authenticate without Keychain access.
    
    FIX 9 NOTE: This stores the OAuth token on disk (chmod 600). This is required
    because macOS LaunchAgent background services cannot access Keychain.
    The tradeoff is documented in setup - user consents to this during Claude Max setup.
    File permissions are set to owner-only (600).
    """
    import json
    
    openclaw_dir = Path.home() / ".openclaw"
    config_file = openclaw_dir / "openclaw.json"
    
    try:
        # Ensure directory exists
        openclaw_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing config or create minimal structure
        if config_file.exists():
            with open(config_file) as f:
                config = json.load(f)
        else:
            config = {}
        
        # Ensure env.vars dict exists
        if "env" not in config:
            config["env"] = {}
        if "vars" not in config["env"]:
            config["env"]["vars"] = {}
        
        # Write the OAuth token
        config["env"]["vars"]["ANTHROPIC_OAUTH_TOKEN"] = oauth_token
        
        # Write config file
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)
        
        # Set permissions (readable only by owner)
        os.chmod(config_file, 0o600)
        
        return True
    except Exception as e:
        print_warning(f"Failed to write OAuth token to config: {e}")
        return False


def _write_discord_to_openclaw_config(token: str, channel_id: str) -> bool:
    """Write Discord config directly to OpenClaw's config file.
    
    This bypasses the 'openclaw config set' CLI which requires the gateway to be running.
    Works on fresh installs before gateway has ever started.
    """
    import json
    
    openclaw_dir = Path.home() / ".openclaw"
    config_file = openclaw_dir / "openclaw.json"
    
    try:
        # Ensure directory exists
        openclaw_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing config or create minimal structure
        if config_file.exists():
            with open(config_file) as f:
                config = json.load(f)
        else:
            config = {}
        
        # Ensure channels dict exists
        if "channels" not in config:
            config["channels"] = {}
        
        # FIX 12: Disclose guild detection API call
        print_info("Checking which server your bot is in...")
        guild_id = _detect_guild_from_token(token)
        
        # Build Discord config
        discord_config = {
            "enabled": True,
            "token": token,
            "groupPolicy": "open",
            "streaming": "off",
        }
        
        if channel_id:
            discord_config["defaultChannel"] = channel_id
        
        if guild_id:
            discord_config["guilds"] = {
                guild_id: {
                    "requireMention": False,
                    "users": ["*"]
                }
            }
        
        config["channels"]["discord"] = discord_config
        
        # Write config file
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)
        
        # Set permissions (readable only by owner)
        os.chmod(config_file, 0o600)
        
        return True
    except Exception as e:
        print_warning(f"Failed to write config: {e}")
        return False


def _detect_guild_from_token(token: str) -> str:
    """Try to detect the guild ID from the bot token.
    
    Returns the guild ID if exactly one guild is found, empty string otherwise.
    """
    try:
        import urllib.request
        import json
        
        req = urllib.request.Request(
            "https://discord.com/api/v10/users/@me/guilds",
            headers={"Authorization": f"Bot {token}"}
        )
        
        with urllib.request.urlopen(req, timeout=10) as resp:
            guilds = json.loads(resp.read().decode())
            if len(guilds) == 1:
                return guilds[0].get("id", "")
    except Exception:
        pass
    
    return ""


def step_license() -> bool:
    """Step 1: License key entry."""
    print_step(1, 6, "License Key")
    
    # Check if already licensed
    status = validate_license()
    if status.valid:
        print_success(f"Already licensed: {status.tier} tier")
        print_info(f"Max agents: {status.max_agents}, Max crons: {status.max_crons}")
        
        change = input("\nChange license key? [y/N]: ").strip().lower()
        if change != "y":
            return True
    
    print("Enter your JUMPSTARTED license key.")
    print_info("You received this in your welcome email after purchase.")
    print_info("It starts with: op_live_...")
    print()
    # UX FIX 2: Add "Don't have a key?" path
    print_info("Don't have a key? Get one at: https://jumpstarted.ai")
    print()
    
    while True:
        try:
            license_key_str = input("License key (or 'buy' to open store): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n")
            print_error("Setup cancelled")
            return False
        
        # UX FIX 2: Handle buy/get/? shortcuts
        if license_key_str.lower() in ("buy", "get", "?"):
            print_info("Opening jumpstarted.ai in your browser...")
            try:
                import subprocess
                subprocess.run(["open", "https://jumpstarted.ai"], check=False)
            except Exception:
                pass
            continue
        
        if not license_key_str:
            print_error("No license key entered")
            retry = input("Try again? [Y/n]: ").strip().lower()
            if retry == "n":
                return False
            continue
        
        if not license_key_str.startswith("op_live_") and not license_key_str.startswith("op_beta_"):
            print_error("Invalid format - license key should start with op_live_ or op_beta_")
            retry = input("Try again? [Y/n]: ").strip().lower()
            if retry == "n":
                return False
            continue
        
        # Try to activate
        print("\nActivating license...")
        result = activate_license(license_key_str)
        
        if result.valid:
            print_success("License activated!")
            print_info(f"Tier: {result.tier}")
            print_info(f"Max agents: {result.max_agents}")
            print_info(f"Max crons: {result.max_crons}")
            return True
        else:
            print_error(f"Activation failed: {result.error}")
            retry = input("Try again? [Y/n]: ").strip().lower()
            if retry == "n":
                return False


def step_claude_api() -> bool:
    """Step 2: Claude API key or Claude Max plan."""
    print_step(2, 6, "Claude AI Setup")
    
    config = load_config()
    
    # Check existing configuration
    existing_mode = config.get("ai_mode")
    existing_key = get_keychain_password("OPERATOR", "ANTHROPIC_API_KEY")
    
    if existing_mode == "claude_wrapper":
        print_success("Claude Max plan configured (using claude-wrapper)")
        change = input("\nChange AI setup? [y/N]: ").strip().lower()
        if change != "y":
            return True
    elif existing_key:
        masked = existing_key[:10] + "..." + existing_key[-4:]
        print_success(f"Claude API key already configured: {masked}")
        change = input("\nChange AI setup? [y/N]: ").strip().lower()
        if change != "y":
            return True
    
    print("How do you want to run AI?")
    print()
    print("  1. I use Claude Pro or Max plan (recommended — no API key needed)")
    print("  2. I have an Anthropic API key (sk-ant-... — advanced users only)")
    print("  3. Hybrid mode: Local AI (BitNet) + Claude for complex tasks")
    print("  4. Local only: Run entirely offline with BitNet (experimental)")
    print()
    print_info("Options 3 & 4 use BitNet b1.58 for lightweight tasks.")
    print_info("BitNet requires ~500MB download, runs on any Mac.")
    print()
    
    choice = input("Choose [1-4]: ").strip()
    
    if choice == "1":
        # Claude Max plan - extract session for background use
        print()
        print_info("Claude Max plan detected.")
        print_info("JUMPSTARTED will use your Claude subscription for AI calls.")
        print()
        
        # Check if Claude CLI is installed
        import shutil
        claude_path = shutil.which("claude")
        if not claude_path:
            possible_paths = [
                os.path.expanduser("~/.npm-global/bin/claude"),
                "/usr/local/bin/claude",
                "/opt/homebrew/bin/claude",
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    claude_path = path
                    break
        
        if not claude_path:
            print_error("Claude CLI not found.")
            print_info("Install it first: npm install -g @anthropic-ai/claude-code")
            print_info("Then log in: claude")
            return False
        
        print_success(f"Claude CLI found at {claude_path}")
        
        # Check if user is logged in by trying to extract session
        print()
        print_info("Checking Claude login status...")
        
        try:
            from claude_session import extract_session, save_session, check_and_warn_expiry
        except ImportError:
            # Fallback import
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                "claude_session", 
                Path(__file__).parent / "claude_session.py"
            )
            claude_session = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(claude_session)
            extract_session = claude_session.extract_session
            save_session = claude_session.save_session
            check_and_warn_expiry = claude_session.check_and_warn_expiry
        
        session = extract_session()
        
        if not session:
            print_warning("You're not logged into Claude CLI yet.")
            print()
            print("Please log in first:")
            print(f"  1. Run: {claude_path}")
            print("  2. Complete the login flow in your browser")
            print("  3. Run this setup again")
            print()
            input("Press Enter after you've logged in...")
            
            # Try again
            session = extract_session()
            if not session:
                print_error("Still not logged in. Please complete Claude login first.")
                return False
        
        # Validate session
        oauth = session.get("claudeAiOauth", {})
        sub_type = oauth.get("subscriptionType", "unknown")
        
        print_success(f"Found {sub_type} subscription")
        
        # FIX 9: Disclose that OAuth token will be stored on disk
        print()
        print_info("To run as a background service, your Claude session token")
        print_info("needs to be saved to disk (Keychain isn't accessible to background services).")
        print_info("The file will be readable only by your user account (chmod 600).")
        print()
        consent = input("Save session token to disk for background use? [Y/n]: ").strip().lower()
        if consent == "n":
            print_warning("Without saving the token, JUMPSTARTED won't work as a background service.")
            print_info("You can use API key mode instead (option 2) if you have Anthropic credits.")
            return False
        
        # Save session for background service use
        print_info("Saving session for background service access...")
        if save_session(session):
            status = check_and_warn_expiry()
            if status["expires_in_hours"]:
                print_success(f"Session valid for {status['expires_in_hours']:.0f} hours")
            
            # Write OAuth token to OpenClaw config for background service
            access_token = oauth.get("accessToken", "")
            if access_token and _write_oauth_to_openclaw_config(access_token):
                print_success("OAuth token saved (chmod 600)")
            
            # Save OPERATOR config
            config["ai_mode"] = "claude_max"
            config["claude_wrapper_path"] = claude_path
            config["claude_session_extracted"] = True
            save_config(config)
            
            print()
            print_success("Claude Max configured for background use!")
            # UX FIX 5: Make session expiry warning prominent
            print()
            print(f"{YELLOW}╔═══════════════════════════════════════════════════════════════╗{RESET}")
            print(f"{YELLOW}║  ⚠️  IMPORTANT: Your Claude session expires in ~30 days.      ║{RESET}")
            print(f"{YELLOW}║  Run 'jmp setup' to refresh it when needed.                   ║{RESET}")
            print(f"{YELLOW}╚═══════════════════════════════════════════════════════════════╝{RESET}")
            return True
        else:
            print_error("Failed to save session.")
            return False
    
    if choice == "3":
        # Hybrid mode: BitNet + Claude
        print()
        print_info("Hybrid mode: BitNet for lightweight tasks, Claude for complex ones.")
        print_info("This saves API costs while maintaining quality for important tasks.")
        
        # Check/install BitNet
        if not _check_bitnet_installed():
            print()
            install = input("Install BitNet now? (~500MB download) [Y/n]: ").strip().lower()
            if install != "n":
                if not _install_bitnet():
                    print_warning("BitNet install failed. Falling back to Claude-only mode.")
                    config["ai_mode"] = "claude_wrapper"
                    save_config(config)
                    return True
        
        # Need Claude for complex tasks - get wrapper or API key
        print()
        print("For complex tasks, how do you access Claude?")
        print("  1. Claude Max plan (claude-wrapper)")
        print("  2. API key")
        sub_choice = input("Choose [1-2]: ").strip()
        
        if sub_choice == "1":
            import shutil
            wrapper_path = shutil.which("claude") or "claude"
            config["claude_wrapper_path"] = wrapper_path
        else:
            api_key = getpass("API Key (hidden): ").strip()
            if api_key:
                set_keychain_password("OPERATOR", "ANTHROPIC_API_KEY", api_key)
        
        config["ai_mode"] = "hybrid"
        save_config(config)
        print_success("Hybrid mode configured (BitNet + Claude)")
        return True
    
    if choice == "4":
        # Local-only mode: BitNet only
        print()
        print_warning("⚠️  LOCAL-ONLY MODE (EXPERIMENTAL)")
        print()
        print("This mode runs entirely offline using BitNet b1.58.")
        print("Limitations:")
        print("  • Lower quality than Claude for complex tasks")
        print("  • Morpheus (code) agent disabled (quality too low)")
        print("  • No tool/function calling support")
        print("  • Best for: summaries, formatting, simple Q&A")
        print()
        proceed = input("Continue with local-only mode? [y/N]: ").strip().lower()
        
        if proceed != "y":
            return step_claude_setup()  # Restart AI setup
        
        # Check/install BitNet
        if not _check_bitnet_installed():
            print()
            print_info("Installing BitNet (required for local mode)...")
            if not _install_bitnet():
                print_error("BitNet installation failed. Cannot continue with local mode.")
                return False
        
        config["ai_mode"] = "local_only"
        save_config(config)
        print_success("Local-only mode configured (BitNet)")
        print_warning("Remember: Quality is limited. Use for lightweight tasks only.")
        return True
    
    # Default: API key flow
    print()
    print("Enter your Anthropic (Claude) API key.")
    print_info("Get one at: https://console.anthropic.com/account/keys")
    print_info("Your key will be stored securely in macOS Keychain.")
    print()
    
    while True:
        api_key = getpass("API Key (hidden): ").strip()
        
        if not api_key:
            print_error("No API key entered")
            retry = input("Try again? [Y/n]: ").strip().lower()
            if retry == "n":
                return False
            continue
        
        if not api_key.startswith("sk-ant-"):
            print_warning("This doesn't look like an Anthropic API key (should start with sk-ant-)")
            proceed = input("Use it anyway? [y/N]: ").strip().lower()
            if proceed != "y":
                continue
        
        # FIX 11: Wrap in try/except and clear sensitive data after use
        try:
            # Store in Keychain and update config
            if set_keychain_password("OPERATOR", "ANTHROPIC_API_KEY", api_key):
                config["ai_mode"] = "api_key"
                save_config(config)
                print_success("API key stored in Keychain")
                return True
            else:
                print_error("Failed to store API key")
                return False
        except Exception as e:
            # Sanitize error message - don't expose key in traceback
            print_error(f"Error storing API key: {type(e).__name__}")
            return False
        finally:
            # Clear sensitive data from memory
            api_key = None


def step_display_name() -> bool:
    """Step 3: Display name."""
    print_step(3, 6, "Your Name")
    
    config = load_config()
    existing = config.get("display_name")
    
    if existing:
        print_info(f"Current name: {existing}")
        change = input("Change name? [y/N]: ").strip().lower()
        if change != "y":
            return True
    
    print("What should your AI team call you?")
    print_info("This is how your agents will address you in responses.")
    print()
    
    while True:
        name = input("Your name: ").strip()
        
        if not name:
            print_warning("Name cannot be blank. Please enter your name.")
            continue
        break
    
    config["display_name"] = name
    save_config(config)
    print_success(f"Name set to: {name}")
    return True


def step_telemetry() -> bool:
    """Step 3b: Telemetry opt-in."""
    print()
    print(f"{BLUE}📊 Help improve JUMPSTARTED?{RESET}")
    print()
    print("   We collect anonymous crash reports and usage stats.")
    print("   We NEVER read your messages, files, or anything personal.")
    print("   You can change this anytime in your config.")
    print()
    
    # FIX 13: Default to opt-OUT (GDPR compliance - silence is not consent)
    choice = input("Send anonymous improvement data? [y/N]: ").strip().lower()
    
    # Require explicit "y" to enable
    enabled = choice == "y"
    
    config = load_config()
    config["telemetry_enabled"] = enabled
    save_config(config)
    
    if enabled:
        print_success("Telemetry enabled — thank you for helping improve JUMPSTARTED!")
    else:
        print_info("Telemetry disabled — no data will be sent")
    
    return True


def _setup_discord_shared_bot(config: dict) -> bool:
    """v2 Discord setup — shared bot, one-click OAuth flow.
    
    User clicks "Add to Discord" → bot is added to their server →
    we auto-detect guild_id via the routing server.
    """
    print()
    print_info("Discord Setup — One-Click")
    print()
    print("This will open your browser to add JUMPSTARTED to your Discord server.")
    print("No bot creation required — just click Authorize.")
    print()
    
    proceed = input("Open browser to add JUMPSTARTED to Discord? [Y/n]: ").strip().lower()
    if proceed == "n":
        print_info("Skipping Discord. Run 'jmp setup' later to connect.")
        return True
    
    # Get license key to track which user is authorizing
    # License key is stored in ~/.operator/license.json, not in config
    from controller import load_license
    license_key = load_license() or ""
    
    # Open OAuth URL in browser with license key for tracking
    oauth_url = f"https://jumpstarted-bot.fly.dev/oauth/invite?license_key={license_key}"
    
    print_info("Opening Discord authorization...")
    try:
        import subprocess
        subprocess.run(["open", oauth_url], check=False)
    except Exception:
        print_warning(f"Could not open browser. Visit: {oauth_url}")
    
    print()
    print_warning("⚠️  IMPORTANT: When the Discord page opens:")
    print("   • Use the dropdown at the top to select YOUR server")
    print("   • It may default to a different server — make sure to switch it!")
    print()
    print("Steps:")
    print("1. Select your server from the dropdown (this is important!)")
    print("2. Click 'Authorize'")
    print("3. Complete any CAPTCHA if prompted")
    print()
    
    input("Press Enter after you have authorized...")
    
    # Auto-detect guild_id via the routing server
    print()
    print_info("Looking up your Discord server...")
    
    guild_id = None
    try:
        import requests
        resp = requests.get(
            f"https://jumpstarted-bot.fly.dev/oauth/guild?license_key={license_key}",
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            guild_id = data.get("guild_id")
            print_success(f"Found your server: {guild_id}")
    except Exception:
        pass
    
    if not guild_id:
        print_warning("Could not auto-detect your server.")
        print()
        print("The success page showed your Guild ID — it's a long number.")
        print("Click on it to copy, then paste it here:")
        print()
        guild_id = input("Guild ID: ").strip()
    
    if not guild_id:
        print_warning("No Guild ID. Skipping Discord setup.")
        print_info("Run 'jmp setup' later to connect.")
        return True
    
    # Get channel ID
    print()
    print_info("Which channel should your agents use?")
    print_info("Right-click the channel → 'Copy Channel ID'")
    print()
    channel_id = input("Channel ID (or press Enter for default): ").strip()
    
    # Register with the routing server
    print()
    print_info("Registering with JUMPSTARTED bot server...")
    
    # Get the user's webhook URL (where the routing server will send events)
    # This is the OpenClaw gateway URL on the user's machine
    local_webhook_url = f"http://localhost:8080/webhook/discord"  # Default OpenClaw port
    
    # License key is stored in ~/.operator/license.json
    from controller import load_license
    license_key = load_license() or ""
    
    try:
        import requests
        resp = requests.post(
            "https://jumpstarted-bot.fly.dev/register",
            json={
                "guild_id": guild_id,
                "license_key": license_key,
                "webhook_url": local_webhook_url,
                "channel_id": channel_id,
            },
            timeout=10,
        )
        
        if resp.status_code == 200:
            print_success("Discord connected!")
            config["channel"] = "discord"
            config["discord_guild_id"] = guild_id
            config["discord_channel_id"] = channel_id
            config["discord_mode"] = "shared_bot"
            save_config(config)
            
            # Write to OpenClaw config
            _write_shared_bot_discord_config(guild_id, channel_id)
            
            return True
        else:
            print()
            print_warning("Something went wrong connecting to JUMPSTARTED servers.")
            print_info("We'll try manual Discord setup instead.")
            print_info("If this keeps happening, email support@jumpstarted.ai")
            print()
            return _setup_discord_manual(config)
    
    except Exception as e:
        print()
        print_warning("Could not reach JUMPSTARTED servers.")
        print_info("We'll try manual Discord setup instead.")
        print_info("If this keeps happening, email support@jumpstarted.ai")
        print()
        return _setup_discord_manual(config)


def _write_shared_bot_discord_config(guild_id: str, channel_id: str) -> bool:
    """Write shared bot Discord config to OpenClaw."""
    import json
    
    openclaw_dir = Path.home() / ".openclaw"
    config_file = openclaw_dir / "openclaw.json"
    
    try:
        openclaw_dir.mkdir(parents=True, exist_ok=True)
        
        if config_file.exists():
            with open(config_file) as f:
                config = json.load(f)
        else:
            config = {}
        
        # For shared bot mode, we don't store a token locally
        # The routing server handles Discord communication
        if "channels" not in config:
            config["channels"] = {}
        
        config["channels"]["discord"] = {
            "enabled": True,
            "mode": "shared_bot",
            "guild_id": guild_id,
            "default_channel": channel_id,
        }
        
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)
        
        os.chmod(config_file, 0o600)
        return True
    except Exception as e:
        print_warning(f"Could not write config: {e}")
        return False


def _setup_discord_manual(config: dict) -> bool:
    """Legacy manual Discord setup (user creates their own bot)."""
    print()
    print_info("Manual Discord Setup")
    print()
    print("Do you have a Discord bot token?")
    has_token = input("[y/N]: ").strip().lower()
    
    if has_token != "y":
        print()
        print_info("To create a Discord bot:")
        print("  1. Go to discord.com/developers/applications")
        print("  2. Click 'New Application' → name it anything")
        print("  3. Go to 'Bot' section → click 'Add Bot'")
        print("  4. Under TOKEN, click 'Copy'")
        print("  5. Go to 'OAuth2' → 'URL Generator'")
        print("     - Scopes: select 'bot'")
        print("     - Bot Permissions: 'Send Messages', 'Read Message History'")
        print("  6. Copy the URL → add bot to your server")
        print()
        ready = input("Ready to enter token? [y/N]: ").strip().lower()
        if ready != "y":
            print_info("Run 'jmp setup' when you have your token.")
            return True
    
    token = getpass("Discord bot token (hidden): ").strip()
    if not token:
        return True
    
    channel_id = input("Channel ID: ").strip()
    
    # Save using existing flow (Keychain + config)
    if set_keychain_password("OPERATOR", "DISCORD_TOKEN", token):
        config["channel"] = "discord"
        config["discord_channel_id"] = channel_id
        config["discord_mode"] = "own_bot"
        save_config(config)
        
        _write_discord_to_openclaw_config(token, channel_id)
        print_success("Discord configured!")
    else:
        print_error("Could not save token")
    
    return True


def step_channels() -> bool:
    """Step 4: Communication channels."""
    print_step(4, 6, "Communication Channel")
    
    config = load_config()
    
    print("How do you want to communicate with your AI team?")
    print()
    print("  1. Discord (one-click setup)")
    print("  2. Discord (advanced - your own bot)")
    print("  3. Telegram")
    print("  4. Web chat only")
    print("  5. Skip for now")
    print()
    
    choice = input("Choose [1-5]: ").strip()
    
    # v2 Shared Bot Flow (recommended)
    if choice == "1":
        return _setup_discord_shared_bot(config)
    
    # v2 Advanced: Use manual setup
    if choice == "2":
        return _setup_discord_manual(config)
    
    # Telegram
    if choice == "3":
        choice = "2"  # Fall through to telegram below
    elif choice == "4":
        choice = "3"  # Web chat
    elif choice == "5":
        choice = "4"  # Skip
    
    # Telegram
    if choice == "2":
        print()
        print_info("To set up Telegram, you'll need a Telegram bot token.")
        print_info("Guide: https://docs.operatorhq.com/setup/telegram")
        print()
        
        token = getpass("Telegram bot token (hidden, or press Enter to skip): ").strip()
        
        if token:
            if set_keychain_password("OPERATOR", "TELEGRAM_TOKEN", token):
                config["channel"] = "telegram"
                save_config(config)
                print_success("Telegram configured")
            else:
                print_error("Failed to store Telegram token")
        else:
            print_info("Skipping Telegram setup")
    
    elif choice == "3":
        config["channel"] = "webchat"
        save_config(config)
        print_success("Web chat only mode configured")
    
    else:
        print_info("Skipping channel setup - you can configure this later")
    
    return True


def step_verify() -> bool:
    """Step 5: Verification and launch."""
    print_step(6, 6, "Verification")
    
    print("Verifying your setup...\n")
    
    all_good = True
    
    # Check license
    status = validate_license()
    if status.valid:
        print_success(f"License: {status.tier} tier")
    else:
        print_error(f"License: {status.error}")
        all_good = False
    
    # Check Claude AI setup
    config = load_config()
    ai_mode = config.get("ai_mode")
    claude_ok = False
    
    if ai_mode == "claude_max":
        # Check for session file from OAuth extraction
        session_file = OPERATOR_HOME / "claude_session.json"
        if session_file.exists():
            try:
                with open(session_file) as f:
                    session_data = json.load(f)
                if session_data.get("sessionKey") or session_data.get("accessToken"):
                    print_success("Claude AI: Max plan (session active)")
                    claude_ok = True
                else:
                    print_warning("Claude AI: session file exists but may be invalid")
            except Exception:
                print_warning("Claude AI: could not read session file")
        else:
            print_error("Claude AI: session not found — run 'jmp setup' to authenticate")
    elif ai_mode == "claude_wrapper":
        wrapper_path = config.get("claude_wrapper_path", "claude")
        import shutil
        # Check if it exists as a path or is in PATH
        if os.path.exists(wrapper_path) or shutil.which(wrapper_path):
            print_success(f"Claude AI: Max plan ({wrapper_path})")
            claude_ok = True
        else:
            print_error(f"Claude AI: claude not found at {wrapper_path}")
            print_info("Install with: npm install -g @anthropic-ai/claude-code")
    elif ai_mode == "hybrid" or ai_mode == "local_only":
        print_success(f"Claude AI: {ai_mode} mode")
        claude_ok = True
    else:
        api_key = get_keychain_password("OPERATOR", "ANTHROPIC_API_KEY")
        if api_key:
            print_success("Claude AI: API key configured")
            claude_ok = True
        else:
            print_error("Claude AI: not configured")
    
    if not claude_ok:
        # Don't hard-fail, ask user
        print()
        proceed = input("Claude session may need refresh. Continue anyway? [y/N]: ").strip().lower()
        if proceed != "y":
            print_info("Run 'jmp setup' to reconfigure Claude.")
            return False
        # User chose to continue, don't mark as failure
        all_good = True  # Override since user accepted
    
    # Check config
    if config.get("display_name"):
        print_success(f"Display name: {config['display_name']}")
    else:
        print_warning("Display name: not set (using system default)")
    
    channel = config.get("channel", "webchat")
    print_info(f"Communication channel: {channel}")
    
    # UX FIX 10: Hardware fingerprint removed from display (no user value)
    # Fingerprint is still used internally for license validation
    
    print()
    
    if all_good:
        # Generate openclaw.yaml based on AI mode
        try:
            from config_generator import write_openclaw_yaml
            write_openclaw_yaml()
        except Exception as e:
            print_warning(f"Could not generate openclaw.yaml: {e}")
        
        print(f"{GREEN}{BOLD}═══ Setup Complete! ═══{RESET}")
        print()
        print("Your JUMPSTARTED AI team is ready to launch.")
        print()
        # UX FIX 9: Web search as post-install tip
        print_info("Tip: Add web search later with: jmp setup --step web-search")
        print()
        
        launch = input("Start JUMPSTARTED now? [Y/n]: ").strip().lower()
        if launch != "n":
            print()
            print_info("Starting JUMPSTARTED...")
            try:
                result = subprocess.run(
                    [str(OPERATOR_DIR / "operator"), "start"],
                    capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    print_success("JUMPSTARTED is now running!")
                    print()
                    print(f"Access your dashboard at: {BLUE}http://localhost:8090{RESET}")
                else:
                    print_warning("Could not auto-start JUMPSTARTED")
                    print_info("Run 'jmp start' manually to launch")
            except Exception as e:
                print_warning(f"Could not auto-start: {e}")
                print_info("Run 'jmp start' manually to launch")
            print()
        
        return True
    else:
        print(f"{YELLOW}Setup incomplete.{RESET}")
        print("Please fix the issues above and run setup again.")
        return False


def send_discord_intro():
    """Send intro message to Discord on first setup."""
    config = load_config()
    
    # Only send once
    if config.get("intro_sent"):
        return
    
    # Check if Discord is configured
    if config.get("channel") != "discord":
        return
    
    channel_id = config.get("discord_channel_id")
    if not channel_id:
        return
    
    # Get bot token
    token = get_keychain_password("OPERATOR", "DISCORD_TOKEN")
    if not token:
        return
    
    # Get display name
    display_name = config.get("display_name", "there")
    
    # FIX 14: Make sender name configurable, default to generic text
    setup_by = config.get("setup_by_name", "your team")
    
    # Build intro message
    message = (
        f"Hey {display_name} — I'm online and your team is ready. 🔥\n\n"
        f"**Try these 3 things in the next 30 minutes:**\n\n"
        f"1. Ask me to research something:\n"
        f"   *Neo, research [any topic] and give me a 3-bullet summary*\n\n"
        f"2. Ask Morpheus to build something small:\n"
        f"   *Morpheus, create a simple Python script that [task]*\n\n"
        f"3. Ask Oracle to plan something:\n"
        f"   *Oracle, what should I focus on this week given [your goal]?*\n\n"
        f"Each agent has a specialty. I coordinate. Morpheus builds. Trinity writes. Oracle plans.\n\n"
        f"Type anything to get started."
    )
    
    try:
        import requests
        resp = requests.post(
            f"https://discord.com/api/v10/channels/{channel_id}/messages",
            headers={
                "Authorization": f"Bot {token}",
                "Content-Type": "application/json"
            },
            json={"content": message},
            timeout=10
        )
        
        if resp.status_code in (200, 201):
            # Mark as sent so we don't repeat
            config["intro_sent"] = True
            save_config(config)
            # UX FIX 11: Make it a moment
            print_success("Your team just said hello in Discord — go check it!")
        else:
            print_warning(f"Could not send intro message (status {resp.status_code})")
    except Exception as e:
        print_warning(f"Could not send intro message: {e}")


def step_web_search() -> bool:
    """Optional step: Web search API key."""
    print_step(5, 6, "Web Search (Optional)")
    
    config = load_config()
    
    # Check if already configured
    existing_key = config.get("brave_api_key")
    if existing_key:
        masked = existing_key[:8] + "..." + existing_key[-4:]
        print_success(f"Brave Search API already configured: {masked}")
        change = input("\nChange API key? [y/N]: ").strip().lower()
        if change != "y":
            return True
    
    print("Want to enable web search for your agent? (Recommended)")
    print()
    print_info("Web search lets your agent look up current information.")
    print_info("Get a free API key at: https://brave.com/search/api")
    print_info("Takes about 2 minutes to sign up.")
    print()
    
    api_key = input("Brave API Key (or press Enter to skip): ").strip()
    
    if not api_key:
        print_info("Skipping web search. You can add it later.")
        return True
    
    # Validate format (Brave keys are typically BSA...)
    if not api_key.startswith("BSA"):
        print_warning("This doesn't look like a Brave API key (usually starts with BSA)")
        proceed = input("Use it anyway? [y/N]: ").strip().lower()
        if proceed != "y":
            print_info("Skipping web search.")
            return True
    
    # Save to OPERATOR config
    config["brave_api_key"] = api_key
    save_config(config)
    
    # Write to OpenClaw config
    if _write_brave_api_to_openclaw_config(api_key):
        print_success("Brave Search API configured")
    else:
        print_warning("Saved to JUMPSTARTED config, but couldn't update OpenClaw config")
    
    return True


def _write_brave_api_to_openclaw_config(api_key: str) -> bool:
    """Write Brave API key to OpenClaw's config."""
    import json
    
    openclaw_dir = Path.home() / ".openclaw"
    config_file = openclaw_dir / "openclaw.json"
    
    try:
        openclaw_dir.mkdir(parents=True, exist_ok=True)
        
        if config_file.exists():
            with open(config_file) as f:
                config = json.load(f)
        else:
            config = {}
        
        # Ensure tools.web.search dict exists
        if "tools" not in config:
            config["tools"] = {}
        if "web" not in config["tools"]:
            config["tools"]["web"] = {}
        if "search" not in config["tools"]["web"]:
            config["tools"]["web"]["search"] = {}
        
        # Write the API key and enable
        config["tools"]["web"]["search"]["enabled"] = True
        config["tools"]["web"]["search"]["provider"] = "brave"
        config["tools"]["web"]["search"]["apiKey"] = api_key
        
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)
        
        os.chmod(config_file, 0o600)
        return True
    except Exception as e:
        print_warning(f"Failed to write Brave API key: {e}")
        return False


def run_wizard(skip_intro: bool = False):
    """Run the full setup wizard."""
    print_header()
    
    print("Welcome to JUMPSTARTED setup!")
    print("This wizard will guide you through the initial configuration.")
    print()
    print_info(f"Configuration will be saved to: {OPERATOR_DIR}")
    print()
    
    # Only prompt for Enter if running interactively and not skipping intro
    if IS_INTERACTIVE and not skip_intro:
        input("Press Enter to continue...")
    
    # UX FIX 9: Web search moved to post-install tip (not in main flow)
    steps = [
        step_license,
        step_claude_api,
        step_display_name,
        step_telemetry,
        step_channels,
        step_verify,
    ]
    
    for step in steps:
        if not step():
            print()
            print_error("Setup cancelled.")
            sys.exit(1)
    
    # Initialize capability level (defaults to Safe Mode)
    try:
        from capability_manager import init_capability_on_upgrade, get_install_disclosure
        
        # Set default capability level
        config = load_config()
        if "capability_level" not in config:
            config["capability_level"] = 1
            config["capability_history"] = [{
                "level": 1,
                "set_at": datetime.now().isoformat() + "Z",
                "reason": "install_default",
            }]
            save_config(config)
        
        # Show Safe Mode disclosure
        print()
        print_success("Setup complete!")
        print()
        disclosure = get_install_disclosure()
        for line in disclosure.split("\n"):
            print(f"  {line}")
        print()
    except ImportError:
        # capability_manager not available (shouldn't happen)
        print()
        print("Thank you for choosing JUMPSTARTED! 🚀")
        print()
    
    # Send intro message to Discord (only on first setup)
    send_discord_intro()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="JUMPSTARTED Setup Wizard")
    parser.add_argument("--step", type=int, help="Run a specific step (1-5)")
    parser.add_argument("--skip-intro", action="store_true", 
                        help="Skip the 'Press Enter to continue' prompt")
    parser.add_argument("--non-interactive", action="store_true",
                        help="Run in non-interactive mode (same as --skip-intro)")
    args = parser.parse_args()
    
    skip_intro = args.skip_intro or args.non_interactive or not IS_INTERACTIVE
    
    if args.step:
        steps = [step_license, step_claude_api, step_display_name, step_channels, step_verify]
        if 1 <= args.step <= 5:
            steps[args.step - 1]()
        else:
            print(f"Invalid step: {args.step}")
            sys.exit(1)
    else:
        run_wizard(skip_intro=skip_intro)


if __name__ == "__main__":
    main()
